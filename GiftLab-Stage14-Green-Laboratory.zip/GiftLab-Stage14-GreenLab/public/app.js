'use strict';
// GIFT LAB Stage 14 · green research laboratory — sandbox deposit demo & read-only market, DEMO ONLY. No redeemable assets.
const tg = window.Telegram?.WebApp;
const $ = q => document.querySelector(q);
const esc = x => String(x ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = n => Number(n||0).toLocaleString('ru-RU');
const color = {common:'#94a3b8',rare:'#38bdf8',epic:'#a78bfa',legendary:'#fbbf24',mythic:'#fb7185'};
const icons = {
  home:'<path d="m3 11 9-8 9 8M5 10v10h5v-6h4v6h5V10"/>',
  cases:'<rect x="3" y="8" width="18" height="4" rx="1"/><path d="M12 8v13M19 12v9H5v-9M7.5 8a2.5 2.5 0 0 1 0-5C11 3 12 8 12 8s1-5 4.5-5a2.5 2.5 0 0 1 0 5"/>',
  games:'<rect x="2" y="6" width="20" height="12" rx="4"/><path d="M6 12h4M8 10v4M15 13h.01M18 11h.01"/>',
  leaders:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0zM17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>',
  profile:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'
};
const TABS=[['home','Главная'],['cases','Кейсы'],['games','Игры'],['leaders','Лидеры'],['profile','Профиль']];
const S={user:null,token:'',cases:[],catalog:[],tab:'home',page:'',caseId:'',game:'',
  period:'week',metric:'earned',leaders:[],mine:null,recent:[],rooms:[],rocket:null,mines:null,
  sourceId:'',sourceIds:[],targetId:'',upgradeStars:0,caseCount:1,stake:50,caseFilter:'all',minerCount:3,battleCase:'starter',battleRounds:3,roomId:'',
  supportStatus:null,supportConfig:null,market:null,marketQuery:'',quoteTon:'1',marketQuote:null,depositMethod:'stars',depositAmount:'500',depositCollection:'Toy Bear',depositQuote:null,depositHistory:[],depositCollections:[],depositSearch:'',isLocalDemo:false,
  set:JSON.parse(localStorage.getItem('gl_settings')||'{"fast":false,"vibe":true}'),busy:false};
const serverPost=(url,body={})=>api(url,{method:'POST',body:JSON.stringify(body)});
async function api(url,opt={}){
  const r=await fetch(url,{...opt,headers:{'Content-Type':'application/json',Authorization:'Bearer '+S.token}});
  const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||'Ошибка сервера');return j;
}
const balance=()=>`<span class="chip lab-balance"><small>DEMO</small> ⭐ ${fmt(S.user.balance)}</span>`;
const depositButton=()=>`<button class="deposit-top" data-act="deposit" title="Лаборатория · финансы" aria-label="Открыть финансовый раздел"><span>＋</span><span class="deposit-top-label">Lab Funds</span></button>`;
const avatar=(u,big=false)=>`<div class="ava${big?' big':''}">${u.photo?`<img src="${esc(u.photo)}" alt="">`:esc((u.name||'?')[0].toUpperCase())}</div>`;
function notify(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(notify.t);notify.t=setTimeout(()=>t.classList.remove('show'),3000);}
function haptic(){try{if(S.set.vibe)tg?.HapticFeedback?.selectionChanged()}catch{}}
const note=`<div class="demo-note"><span class="lab-live-light"></span> ИССЛЕДОВАТЕЛЬСКИЙ РЕЖИМ · Баланс и призы виртуальные, не обмениваются на настоящие NFT</div>`;
const artImg=i=>i?.image?`<img class="tg-gift-img" src="${esc(i.image)}" alt="" loading="lazy" referrerpolicy="no-referrer" onerror="this.style.display='none'"><span class="gift-fallback">${i.emoji||i.e||'🎁'}</span>`:`<span class="gift-fallback">${i.emoji||i.e||'🎁'}</span>`;
const itemArt=i=>`<div class="gift" style="--c:${color[i.rarity||i.r?.toLowerCase()]||'#8b5cf6'}">${artImg(i)}</div>`;
const itemTile=(i,withSell=true)=>`<div class="owned"><div class="owned-art">${itemArt(i)}</div><b>${esc(i.name)}</b><span class="mut sm">${fmt(i.value)} ⭐ · ${i.kind==='collectible-preview'?'NFT-коллекция (демо)':i.kind==='regular'?'Обычный подарок':esc(i.rarity)}</span>${withSell?`<button class="small-action" data-act="sell" data-id="${esc(i.instanceId)}">Продать за ${fmt(i.value)} ⭐</button>`:''}</div>`;
const box=c=>`<svg viewBox="0 0 120 120" aria-hidden="true"><defs><linearGradient id="g${c.id}" x1="0" x2="1" y1="0" y2="1"><stop stop-color="${c.color}"/><stop offset="1" stop-color="#191d34"/></linearGradient></defs><rect x="20" y="51" width="80" height="57" rx="12" fill="url(#g${c.id})"/><rect x="14" y="38" width="92" height="22" rx="8" fill="${c.color}"/><rect x="54" y="38" width="12" height="70" fill="#fff" opacity=".82"/><path d="M60 38C42 14 26 33 42 38M60 38C78 14 94 33 78 38" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round"/></svg>`;
const stakeEntry=(isLocked=false)=>`<div class="stake-editor"><label for="customStake" class="mut sm">Своя сумма демо-звёзд</label><div class="stake-entry-row"><input id="customStake" class="text-input" type="number" min="1" max="100000" step="1" inputmode="numeric" value="${S.stake}" ${isLocked?'disabled':''} aria-label="Введите сумму демо-звёзд"><span class="star-ending">⭐</span></div><small class="mut">От 1 до 100 000 · только демо-баланс</small></div>`;
const caseSigils={starter:'⌁',lucky:'✶',gift:'◇',bloom:'✦',premium:'⟁',neon:'◈',legendary:'⬡',winter:'❆',black:'◎',ultimate:'✧'};
const caseSigil=c=>caseSigils[c.id]||({telegram:'⌁',black:'⬡',winter:'✳',neon:'✦'}[c.theme]||'◈');
// Each case has a signature collage built from its actual in-case gifts,
// not a generic repeated box icon or an unrelated collectible.
const caseShowcase=c=>{
  const candidates=(c.items||[]).filter(x=>x.kind==='collectible-preview');
  const pool=(candidates.length?candidates:(c.items||[]).filter(x=>x.kind==='regular'));
  const selected=[...pool].sort((a,b)=>b.value-a.value).slice(0,3);
  return selected.map((i,k)=>`<span class="showcase-gift showcase-${k+1}" aria-hidden="true">${artImg({image:i.image,emoji:i.e})}</span>`).join('')||`<span class="showcase-placeholder">✦</span>`;
};
const stage12CaseArt={micro:'neon',snoop:'whale',newyear:'winter',pepe:'collectors',durovex:'durov',holidaymini:'winter',starter:'signal',lucky:'neon',gift:'signal',bloom:'neon',premium:'durov',neon:'black',legendary:'signal',vault:'winter',nova:'neon',royal:'collectors',mythic:'durov',cosmos:'winter',elite:'black',diamond:'winter',exclusive:'whale',ultimate:'collectors'};
const caseArtwork=c=>`assets/cases/${stage12CaseArt[c.id]||'whale'}.webp`;
const liveCollage=c=>['snoop','newyear','pepe','durovex','holidaymini','micro'].includes(c.id);
const caseTile=c=>`<button class="case gl12-case lab-specimen theme-${c.theme||'neon'}" style="--c:${c.color}" data-act="case" data-id="${esc(c.id)}" aria-label="Открыть кейс ${esc(c.name)} за ${fmt(c.price)} демо-звёзд">
  <span class="gl12-art-panel"><span class="lab-case-overprint">SPECIMEN · ${esc(c.id).toUpperCase()}</span><span class="gl12-title">${esc(c.name)}</span><span class="gl12-demo">LAB / DEMO</span>${liveCollage(c)?`<span class="gl13-collage gl13-${esc(c.id)}"><span class="gl13-aura"></span><span class="gl13-chest">✧</span>${caseShowcase(c)}</span>`:`<img class="gl12-cover-img" src="${caseArtwork(c)}" loading="lazy" alt="Иллюстрация кейса ${esc(c.name)}">`}<span class="gl12-art-shine"></span></span>
  <span class="gl12-case-bottom"><span class="gl12-cost"><span class="gl12-star">★</span>${fmt(c.price)}</span><span class="gl12-open-btn">Исследовать <span>↗</span></span></span>
</button>`;
const menuHeader=(title,extra='')=>`<div class="top"><div><span class="eyebrow">EXPERIMENTAL DIVISION <span>· STAGE 14.0</span></span><h1>${title}</h1></div><div class="row">${balance()}${depositButton()}${extra}</div></div>`;
const back=()=>`<button class="back" data-act="back">‹ Назад</button>`;
const empty=(emoji,txt)=>`<div class="card empty"><i>${emoji}</i>${txt}</div>`;
const gameTiles=[['upgrade','UPGRADE','⟰','Синтез подарков','linear-gradient(135deg,#124f3b,#08281f)'],['rocket','ROCKET','↗','Лётные испытания','linear-gradient(135deg,#256f44,#0a2930)'],['mines','MINES','◆','Исследуй кристаллы','linear-gradient(135deg,#204e35,#112f28)'],['pvp','CASE BATTLE','◈','Соревнование лабораторий','linear-gradient(135deg,#596527,#203122)']];
const gameTile=g=>`<button class="game-tile" data-act="game" data-id="${g[0]}" style="--bg:${g[4]}"><span class="game-art">${g[2]}</span><b>${g[1]}</b><span class="mut sm">${g[3]}</span><span class="go-arrow">↗</span></button>`;

const marketEntry=p=>`<div class="market-entry"><div class="market-glyph">✦</div><div class="grow"><b>${esc(p.name)}</b><small>${esc(p.observationDate)} · ${esc(p.source)}${p.stale?' · устарело':''}</small></div><div class="market-values"><strong>${p.stale?'—':esc(p.floorTon)+' TON'}</strong><small>Справочная цена · ${p.stale?'нет свежей цены':'не live-оффер'}</small></div></div>`;
const slugify=x=>String(x||'').toLowerCase().replace(/[^a-z0-9]/g,'');
const marketSources=[['TON Gifts Wiki','https://tongifts.wiki/en'],['gifts.supply','https://gifts.supply/catalog'],['Gift Loot','https://gift-loot.com/gift/en/'],['Getgems','https://getgems.io/']];
const labSupportBlock=()=>{
 const status=S.supportStatus,active=!!status?.enabled,hasBadge=!!status?.labSupporter;
 return `<section class="lab-support card"><div class="lab-support-art"><img src="assets/lab/logo.svg" alt=""></div><div class="lab-support-head"><div><span class="eyebrow">SUPPORT RESEARCH · XTR</span><h3>Lab Supporter</h3></div><span class="badge">25 Telegram Stars</span></div>
 <p>Официальная покупка постоянного цифрового значка в Telegram. Stars поступают боту, а значок отображается в твоём профиле. Это <b>не пополнение игрового баланса</b> и не ставка.</p>
 <div class="lab-product-features"><span>✓ Не передаётся другим</span><span>✓ Не выводится в TON</span><span>✓ Не влияет на игры</span></div>
 ${hasBadge?'<div class="lab-support-confirmed">✓ Lab Supporter активирован</div>':`<button class="btn full" data-act="buy-supporter" ${!active||!tg?.initData?'disabled':''}>${active&&tg?.initData?'Купить значок · 25 ⭐':'Платёж недоступен в демо-режиме'}</button>`}
 <small class="mut">${active?'Счёт создаётся ботом через Telegram XTR. Подтверждение получения — только после события successful_payment.': 'Официальные счета подключаются только с BOT_TOKEN и настройкой тестового Telegram окружения.'}</small>
 ${status?.lastOrder?.status==='pending'?'<p class="mut sm">Последний заказ ожидает подтверждения Telegram.</p>':''}</section>`;
};
const pages={
  market(){const m=S.market;return `${back()}${menuHeader('Рынок подарков')}
    <div class="market-banner"><span class="eyebrow">GIFTLAB · COLLECTION INTELLIGENCE</span><h2>Цены коллекций<br><em>без догадок.</em></h2><p>Наблюдавшиеся флор-прайсы в TON. Цены относятся ко всей коллекции, не к отдельной модели. Это не цена гарантированной покупки.</p></div>
    <div class="market-stat"><div><small>Коллекций с записями</small><b>${m?.total??'—'}</b></div><div><small>Последняя синхронизация</small><b>${m?.asOf?new Date(m.asOf).toLocaleDateString('ru-RU'):'нет данных'}</b></div></div>
    <div class="card market-warn">Маркет-данные и условные игровые цены — разные показатели. Если данные старше 48 часов, актуальная оценка недоступна. Здесь нет покупки, продажи или передачи настоящих NFT.</div>
    <div class="sectionhead"><h2>Коллекции</h2><button data-act="market-refresh">↻ Обновить</button></div>
    <div class="row market-search"><input class="text-input grow" id="marketSearch" value="${esc(S.marketQuery)}" placeholder="Название коллекции"><button class="btn alt" data-act="market-search">Найти</button></div>
    <div class="market-list">${m?.items?.length?m.items.slice(0,120).map(marketEntry).join(''):empty('◇','Свежие цены пока недоступны. Сервер не подставляет вымышленные числа.')}</div>
    <p class="mut sm space">Данные: <a target="_blank" rel="noopener noreferrer" href="https://tggifts.com/data">TG Gifts (CC BY 4.0)</a>. Ежедневный снимок, не поток действующих заявок. ${m?.asOf?'Загружено: '+esc(m.asOf):'Пока не загружено.'}</p>
    <h2 class="space">Каталоги для проверки</h2><div class="market-links">${marketSources.map(([n,u])=>`<a target="_blank" rel="noopener noreferrer" href="${u}">${esc(n)} ↗</a>`).join('')}</div>
    ${m?.errors?.length?`<details class="card space"><summary>Ошибки источников</summary>${m.errors.map(e=>`<p class="mut sm">${esc(e.source)}: ${esc(e.message)}</p>`).join('')}</details>`:''}`},
  deposit(){const method=S.depositMethod||'stars';const q=S.depositQuote;const collectible=S.catalog.filter(x=>x.kind==='collectible-preview');
    const verified=S.depositCollections.find(x=>x.name===S.depositCollection)||S.depositCollections[0];
    const selected=verified?(collectible.find(x=>x.name===verified.name)||{name:verified.name,image:verified.image,emoji:verified.emoji,rarity:'epic',kind:'collectible-preview',value:0}):null;
    const marketItem=verified;
    return `${back()}${menuHeader('Deposit')}
      <div class="deposit-hero"><div class="deposit-mini-mark">GL <span>PRIVATE SANDBOX</span></div><h2>Пополнение<br><em>демо-баланса.</em></h2><p>Внутренние ⭐ не являются Telegram Stars и не выводятся в TON. Реальные платежи и приём NFT отключены.</p><div class="deposit-security"><span>◉ Без реальных переводов</span><span>◈ Серверная история</span></div></div>
      <div class="deposit-switch" role="tablist">${[['stars','Stars'],['ton','TON'],['nft','NFT Gifts']].map(([k,v])=>`<button role="tab" aria-selected="${method===k}" data-act="deposit-mode" data-id="${k}" class="${method===k?'active':''}">${v}</button>`).join('')}</div>
      ${method==='stars'?`<div class="deposit-panel"><div class="deposit-panel-head"><span class="deposit-status">SANDBOX</span><h3>Демо-звёзды</h3><p>Проверь начисление, историю и защиту от повтора операции. Настоящие Stars не списываются.</p></div><label for="depositAmount">Сумма пополнения</label><div class="deposit-input"><input id="depositAmount" type="number" min="1" max="50000" inputmode="numeric" value="${esc(S.depositAmount)}"><span>⭐</span></div><div class="quick-options">${[100,500,1000,5000].map(n=>`<button data-act="deposit-preset" data-id="${n}">${fmt(n)} ⭐</button>`).join('')}</div><div class="deposit-math"><span>Бонус</span><strong>0%</strong><span>Демо-комиссия · 2%</span><strong>−${Math.ceil((Number(S.depositAmount)||0)*0.02)} ⭐</strong><span>Поступит</span><strong>${fmt(Math.max(0,(Number(S.depositAmount)||0)-Math.ceil((Number(S.depositAmount)||0)*0.02)))} ⭐</strong></div><button class="btn full deposit-main-btn" data-act="deposit-sandbox-credit" ${!S.isLocalDemo?'disabled':''}>${S.isLocalDemo?'Начислить тестовые звёзды ↗':'В Telegram-режиме отключено'}</button><p class="mut sm">Тестовое зачисление работает только на локальном сервере без BOT_TOKEN. Не является платёжной услугой.</p></div>`:
        method==='ton'?`<div class="deposit-panel"><div class="deposit-panel-head"><span class="deposit-status">ESTIMATE ONLY</span><h3>TON · предварительная оценка</h3><p>Внутренний расчёт бонуса 5%. Нет подключения кошелька и нет реального пополнения.</p></div><label for="depositAmount">Количество TON</label><div class="deposit-input"><input id="depositAmount" type="text" inputmode="decimal" value="${esc(S.depositAmount)}"><span>TON</span></div><button class="btn full deposit-main-btn" data-act="deposit-quote">Рассчитать сумму</button>${q?.method==='ton'?`<div class="deposit-quote"><div><span>Базовая сумма</span><b>${esc(q.amountTon)} TON</b></div><div><span>Внутренний демо-бонус · 5%</span><b>+${esc(q.bonusTon)} TON</b></div><div class="quote-sum"><span>Расчётный эквивалент</span><b>${esc(q.totalTon)} TON</b></div>${q.totalInternalStars?`<div><span>Базовые демо-звёзды</span><b>${esc(q.baseInternalStars)} ⭐</b></div><div><span>Бонус +5% (в ⭐)</span><b>+${esc(q.bonusInternalStars)} ⭐</b></div><div class="quote-sum"><span>Итого демо-звёзд</span><b>${esc(q.totalInternalStars)} ⭐</b></div>`:'<p class="mut sm">Конвертация в ⭐ недоступна: администратор ещё не указал внутреннюю расчётную цену 1 демо-звезды (DEMO_STAR_USD) или свежий курс TON/USD не получен. Значения не выдумываются.</p>'}</div>`:''}<div class="deposit-warning">● Переводить реальные TON сюда нельзя. Для будущих платежей требуются юридическая проверка и независимый аудит.</div></div>`:
        `<div class="deposit-panel"><div class="deposit-panel-head"><span class="deposit-status">VERIFIED COLLECTIONS · DEMO</span><h3>NFT Gifts</h3><p>Только коллекции с проверенным недавним наблюдением флора. Цены носят справочный характер, реальные подарки не принимаются.</p></div>
          <div class="nft-search"><input class="text-input grow" id="depositSearch" placeholder="Поиск подарка или коллекции" value="${esc(S.depositSearch||'')}"><button class="btn alt" data-act="deposit-search">Найти</button></div>
          <div class="nft-deposit-grid">${S.depositCollections.filter(x=>!S.depositSearch||slugify(x.name).includes(slugify(S.depositSearch))).map(x=>`<button type="button" class="nft-deposit-card ${selected?.name===x.name?'on':''}" data-act="deposit-nft-pick" data-id="${esc(x.name)}"><span class="nft-deposit-art">${artImg(x)}</span><b>${esc(x.name)}</b><span class="nft-deposit-price">${esc(x.floorTon)} TON</span><small>Оценка −${x.discountPercent}%</small></button>`).join('')||'<div class="mut sm" style="grid-column:1/-1;padding:20px">Нет коллекций со свежей проверенной ценой. Пополнение NFT временно недоступно — выдуманные цены не отображаются.</div>'}</div>
          ${selected?`<div class="deposit-collection"><div class="deposit-preview-art">${itemArt(selected)}</div><div><h3>${esc(selected.name)}</h3><p>Коллекционный подарок · наблюдённый флор</p><strong>${esc(verified?.floorTon||'—')} TON</strong><small class="mut">${esc(verified?.source||'')} · ${esc(verified?.observedAt||'')}</small></div></div>`:''}
          <div class="deposit-math"><span>Единое снижение оценки</span><strong>7% · демо</strong><span>Оценка после снижения</span><strong>${verified?esc(verified.creditTon)+' TON':'Недоступно'}</strong></div>
          <button class="btn full deposit-main-btn" data-act="deposit-nft-quote" ${!selected?'disabled':''}>Проверить оценку</button>
          ${q?.method==='nft'&&q.collection===selected?.name?`<div class="deposit-quote"><div><span>Наблюдавшийся флор</span><b>${q.floor?.available?esc(q.floor.floorTon)+' TON':'Недоступен'}</b></div><div><span>Оценка −7%</span><b>${q.creditTon?esc(q.creditTon)+' TON':'Недоступна'}</b></div></div>`:''}
          <button class="btn alt full" data-act="deposit-nft-request" ${!S.isLocalDemo||!selected?'disabled':''}>Создать тестовую заявку</button>
          <p class="mut sm">Без перевода NFT и настоящего зачисления. Источник: TG Gifts / Fragment (ежедневные наблюдения). Для live-оценки нужен согласованный API Getgems и проверка актуального объявления.</p>
        </div>`}

      ${labSupportBlock()}<div class="sectionhead"><h2>История операций</h2><button data-act="deposit-history">↻ Обновить</button></div><div class="deposit-history">${S.depositHistory.length?S.depositHistory.map(x=>`<div class="deposit-hist-item"><div><b>${x.method==='nft'?'Запрос NFT: '+esc(x.collection):fmt(x.amount)+' ⭐'}</b><small>${new Date(x.createdAt).toLocaleString('ru-RU')}</small></div><span class="deposit-tag">${x.status==='sandbox-confirmed'?'Тест зачислен':'Ожидает · тест'}</span></div>`).join(''):'<div class="mut sm deposit-nohistory">Пока нет тестовых операций</div>'}</div>`},
  home(){return `<div class="top"><div><span class="eyebrow">RESEARCH FACILITY · EST. 2026</span><span class="brand"><img src="assets/lab/logo.svg" alt="" class="lab-brand-icon">GIFT<span>LAB</span></span></div><div class="row">${balance()}${depositButton()}${avatar(S.user)}</div></div>
    ${note}<button class="market-cta" data-act="market"><span>◈ Рыночный обзор <small>Флор коллекций · дата наблюдения</small></span><strong>Открыть ↗</strong></button><div class="live-strip"><div class="live-title"><span class="live-dot"></span> LIVE DROPS <small>Коллекционные · все, обычные · выборка</small></div><div class="live-scroll">${S.recent.filter(x=>x.type==='case').slice(0,12).map(x=>`<div class="live-drop ${x.prizeKind==='collectible-preview'?'featured':''}"><span>${x.prizeKind==='collectible-preview'?'✦':'🎁'}</span><b>${esc(x.name)}</b><small>${esc(x.message.replace(/^Кейс [^:]+:\s*/,''))}</small></div>`).join('')||'<span class="mut sm">Открывай кейсы — результаты появятся здесь</span>'}</div></div><div class="hero gl12-hero gl14-hero"><div class="gl12-hero-art" aria-hidden="true"></div><div class="hero-glow"></div><span class="hero-g1">✧</span><span class="hero-g2">◇</span><span class="eyebrow gl14-lab-eyebrow">● ЛАБОРАТОРИЯ КОЛЛЕКЦИЙ / 014</span><h1>Смешивай.<br>Исследуй.<br><em>Открывай новое.</em></h1><p>Экспериментальная коллекция кейсов и виртуальных подарков.</p><button class="btn" data-act="tab" data-id="cases">К экспериментам <span>↗</span></button></div>
    <div class="sectionhead"><h2>Популярные кейсы</h2><button data-act="tab" data-id="cases">Все →</button></div><div class="gl12-featured-cases">${S.cases.filter(c=>[25,1000,2500].includes(c.price)).map(caseTile).join('')}</div>
    <div class="sectionhead"><h2>Игровая зона</h2><button data-act="tab" data-id="games">Все →</button></div><div class="grid2">${gameTiles.slice(0,2).map(gameTile).join('')}</div>
    <div class="sectionhead"><h2>Активность игроков</h2><button data-act="refresh-recent">↻</button></div><div class="card feed">${S.recent.length?S.recent.slice(0,5).map(x=>`<div class="feed-row"><span class="feed-icon">${x.type==='case'?'🎁':x.type==='sale'?'⭐':'✦'}</span><div><b>${esc(x.name)}</b><div class="mut sm">${esc(x.message)}</div></div></div>`).join(''):'<div class="mut sm">Первые результаты появятся здесь после игр.</div>'}</div>`},
  cases(){return `${menuHeader('Кейсы')}${note}<p class="mut intro">${S.cases.length} тематических кейсов от 25 ⭐ и выше. Демонстрационная коллекция без реальных призов. Все игровые результаты исключительно виртуальные.</p><div class="case-filters">${[['all','Все'],['low','До 200 ⭐'],['mid','200–999 ⭐'],['high','От 1 000 ⭐']].map(([k,t])=>`<button class="pill ${S.caseFilter===k?'on':''}" data-act="case-filter" data-id="${k}">${t}</button>`).join('')}</div><div class="gl12-case-grid">${S.cases.filter(c=>S.caseFilter==='all'||S.caseFilter==='low'&&c.price<200||S.caseFilter==='mid'&&c.price>=200&&c.price<1000||S.caseFilter==='high'&&c.price>=1000).map(caseTile).join('')}</div>`},
  case(){const c=S.cases.find(x=>x.id===S.caseId);if(!c)return empty('🎁','Кейс не найден');const qty=S.caseCount||1;return `${back()}<div class="case-spot modern-spot theme-${c.theme||'neon'}" style="--c:${c.color}"><div class="spot-cover gl12-detail-art">${liveCollage(c)?`<span class="gl13-collage gl13-${esc(c.id)}"><span class="gl13-aura"></span><span class="gl13-chest">✧</span>${caseShowcase(c)}</span>`:`<img src="${caseArtwork(c)}" alt="Обложка ${esc(c.name)}" loading="lazy">`}</div><h1>${esc(c.name)}</h1><div class="price">${fmt(c.price)} ⭐ / кейс</div><span class="mut sm">${c.items.length} различных призов</span></div>
    <div class="card row sp"><span class="quick-open-label">⚡ Быстрое открытие <small>Без долгой прокрутки</small></span><button class="sw ${S.set.fast?'on':''}" data-act="toggle-fast" aria-label="Быстрое открытие"></button></div>
    <h2 class="pick-label">Сколько открыть одновременно?</h2><div class="case-quantity">${[1,2,3].map(n=>`<button class="qty ${qty===n?'selected':''}" data-act="case-count" data-id="${n}">${n} × <small>${n===1?'один':n===2?'два':'три'}</small></button>`).join('')}</div>
    <button class="btn full space open-cases-btn" data-act="open" data-id="${c.id}" ${S.user.balance<c.price*qty?'disabled':''}>Открыть ${qty} ${qty===1?'кейс':qty===2?'кейса':'кейса'} · ${fmt(c.price*qty)} ⭐</button>
    <h2 class="space">Призы внутри <span class="mut sm">· ${c.items.length}</span></h2><div class="card drop-list">${c.items.slice().sort((a,b)=>a.value-b.value).map(i=>`<div class="drop-item">${itemArt({rarity:i.r.toLowerCase(),image:i.image,emoji:i.e})}<div class="grow"><b>${esc(i.n)}</b><small style="color:${color[i.r.toLowerCase()]}">${i.kind==='stars'?'На демо-баланс':i.kind==='regular'?'Обычный подарок':'Коллекция · тестовый приз'}</small></div><div class="drop-right"><b>${fmt(i.value)} демо ⭐</b></div></div>`).join('')}</div>
    <p class="mut sm space">Тестовая игра. Демо-призы не имеют денежной стоимости.</p>`},
  games(){return `${menuHeader('Игры')}${note}<p class="mut intro">Играй на демо-звёзды. Случайные результаты рассчитывает сервер.</p><div class="grid2">${gameTiles.map(gameTile).join('')}</div>`},
  leaders(){const metricNames={earned:'Получено ⭐',cases:'Открыто кейсов',upgrades:'Апгрейдов',pvp:'Побед PvP',spent:'Потрачено ⭐',sales:'Продаж подарков',gameWins:'Побед в играх'};return `${menuHeader('Лидеры')}${note}<div class="seg" style="margin-top:12px">${[['today','Сегодня'],['week','Неделя'],['all','Всё время']].map(([v,t])=>`<button class="${S.period===v?'on':''}" data-act="period" data-id="${v}">${t}</button>`).join('')}</div>
    <select id="leaderMetric" class="select" aria-label="Категория лидеров">${Object.entries(metricNames).map(([k,v])=>`<option value="${k}" ${S.metric===k?'selected':''}>${v}</option>`).join('')}</select>
    ${S.mine?`<div class="myrank"><span>Твоё место</span><b>#${S.mine.rank}</b><span>${fmt(S.mine.value)} ${['earned','spent'].includes(S.metric)?'⭐':''}</span></div>`:''}
    <div class="card rank-list">${S.leaders.length?S.leaders.map(x=>`<div class="rank-row ${x.isMe?'mine':''}"><div class="rank-index ${x.rank<=3?'top-rank':''}">${x.rank===1?'🥇':x.rank===2?'🥈':x.rank===3?'🥉':x.rank}</div>${avatar(x)}<b class="grow">${esc(x.name)}${x.isMe?' <span class="you">ты</span>':''}</b><strong>${fmt(x.value)}</strong></div>`).join(''):'<div class="mut sm">Пока нет игроков</div>'}</div><p class="mut sm space">Рейтинг основан на реальной статистике игроков этого демо-сервера, не на вымышленных аккаунтах.</p>`},
  profile(){const u=S.user,st=u.stats;return `<div class="top">${avatar(u,true)}<div class="grow"><span class="eyebrow">МОЙ ПРОФИЛЬ</span><h1>${esc(u.name)}</h1><span class="mut sm">${u.username?'@'+esc(u.username)+' · ':''}${esc(u.id)}</span></div></div>${note}
    ${u.labSupporter?'<div class="lab-support-confirmed">⌬ LAB SUPPORTER · подтверждённая покупка XTR</div>':''}<div class="wallet"><span class="eyebrow">МОЙ БАЛАНС</span><div class="wallet-value">${fmt(u.balance)} <span>⭐</span></div><p>Демо-звёзды · без денежной стоимости</p><button class="btn alt" data-act="claim">+ Получить 5 000 ⭐</button></div>
    <div class="sectionhead"><h2>Статистика</h2></div><div class="stats">${[['Открыто кейсов',st.cases],['Подарков',st.items],['Апгрейдов',st.upgrades],['PvP побед',st.pvp],['Продано подарков',st.sales],['Побед в мини-играх',st.gameWins]].map(([t,v])=>`<div class="card"><strong>${fmt(v)}</strong><span class="mut sm">${t}</span></div>`).join('')}</div>
    <div class="sectionhead"><h2>Мои подарки <span class="count">${u.inventory.length}</span></h2></div><p class="mut sm">Продажа по 100% условной цены без комиссии. Это не продажа реальных NFT.</p>
    ${u.inventory.length?`<div class="sell-all-row"><span><b>Всё содержимое</b><small>${u.inventory.length} шт. · ${fmt(u.inventory.reduce((s,i)=>s+i.value,0))} ⭐</small></span><button class="btn sell-all" data-act="sell-all">Продать всё</button></div><div class="grid2 space">${u.inventory.map(i=>itemTile(i)).join('')}</div>`:empty('🎒','Инвентарь пуст. Открой кейс и получи первый подарок!')}
    <div class="sectionhead"><h2>История</h2></div><div class="card history">${u.history.length?u.history.slice(0,15).map(x=>`<div class="hist-row"><div><b>${esc(x.message)}</b><small>${new Date(x.time).toLocaleString('ru-RU')}</small></div><span class="${x.delta>0?'plus-amount':'minus-amount'}">${x.delta>0?'+':''}${x.delta?fmt(x.delta)+' ⭐':'—'}</span></div>`).join(''):'Нет операций'}</div>`},
  upgrade(){const inv=S.user.inventory;const selected=inv.filter(x=>S.sourceIds.includes(x.instanceId));const stars=S.upgradeStars||0;const total=selected.reduce((a,x)=>a+x.value,0)+stars;const targets=S.catalog.filter(x=>x.kind!=='stars'&&x.value>total).sort((a,b)=>a.value-b.value);const target=targets.find(x=>x.id===S.targetId)||targets[0];const chance=target&&total?Math.min(.9,.9*total/target.value):0;return `${back()}${menuHeader('Upgrade')}${note}
    <div class="upgrade-compact" id="upgradeMotion"><div class="upgrade-arc upgrade-arc-small" id="upgradeWheel" style="--chance:${chance*360}deg"><div class="wheel-inner"><span class="eyebrow">ШАНС УСПЕХА</span><strong>${(chance*100).toFixed(2)}%</strong><small>СЕРВЕРНЫЙ РЕЗУЛЬТАТ</small></div><span class="needle" id="spinNeedle"></span></div>
    <div class="upgrade-preview"><div><small>ВАШ ВКЛАД</small><div class="up-chips">${selected.slice(0,3).map(itemArt).join('')}${stars?'<span class="up-star">⭐</span>':''}</div><b>${fmt(total)} ⭐</b></div><span class="up-arrow">⇢</span><div><small>ЦЕЛЬ</small>${target?itemArt(target):'<div class="gift">🎯</div>'}<b>${target?fmt(target.value)+' ⭐':'Выбери вклад'}</b></div></div>
    <div id="upgradeResultInline" aria-live="polite"></div></div>
    <button class="btn full upgrade-cta" id="upgradeCTA" data-act="upgrade-spin" ${!target||!total||stars>S.user.balance?'disabled':''}>↗ Улучшить · ${(chance*100).toFixed(2)}%</button>
    <h2 class="space">До 3 подарков <span class="mut sm">${selected.length}/3 выбрано</span></h2>${inv.length?`<div class="selection-scroll">${inv.map(i=>`<button data-act="source-toggle" data-id="${i.instanceId}" class="select-item ${S.sourceIds.includes(i.instanceId)?'active':''}">${itemArt(i)}<b>${fmt(i.value)} ⭐</b></button>`).join('')}</div>`:empty('🎒','Подарков нет — можно улучшать просто за демо-звёзды.')}
    <h2 class="space">Добавить демо-звёзды</h2><div class="stake-entry-row upgrade-star-row"><input class="text-input" id="upgradeStars" type="number" min="0" max="${Math.min(S.user.balance,100000)}" inputmode="numeric" value="${stars}" placeholder="0" aria-label="Добавить демо-звёзды"><span class="star-ending">⭐</span></div><div class="mut sm space">Можно поставить только звёзды, без подарков. Цена цели должна быть выше суммы вклада.</div>
    <h2 class="space">Выбери цель</h2>${targets.length?`<div class="selection-scroll">${targets.map(i=>`<button data-act="target" data-id="${i.id}" class="select-item ${target?.id===i.id?'active':''}">${itemArt(i)}<b>${fmt(i.value)} ⭐</b></button>`).join('')}</div>`:empty('🎯','Сумма вклада слишком велика — уменьши её.')}
    <p class="mut sm space">Формула демо-шанса: 90% × вклад / цена цели, максимум 90%. При неудаче выбранные подарки и звёзды теряются.</p>`},
  rocket(){const r=S.rocket;const phase=r?.status||'waiting',bet=r?.hasBet;return `${back()}${menuHeader('Rocket')}${note}
    <div class="rocket-stage rocket-rework ${phase==='waiting'?'preflight':'inflight'}" id="rocketStage"><div class="rocket-grid"></div><div class="gl12-planet" aria-hidden="true"></div><div class="gl12-orbit" aria-hidden="true"></div><div class="rocket-moons">✧　·　✦　·　✧</div>
      <div class="rocket-ship" id="rocketShip"><svg class="rocket-vector" viewBox="0 0 100 160" aria-label="Ракета"><defs><linearGradient id="rocketMetal" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#fff"/><stop offset=".4" stop-color="#c8dff8"/><stop offset="1" stop-color="#5b82b8"/></linearGradient><linearGradient id="rocketFire" x1="0" y1="0" x2="0" y2="1"><stop stop-color="#fff5c2"/><stop offset=".5" stop-color="#fd9b36"/><stop offset="1" stop-color="#eb3155"/></linearGradient></defs><path class="svg-flame" d="M41 113Q28 143 50 158Q72 142 59 113Z" fill="url(#rocketFire)"/><path d="M30 83 12 109 17 129 38 115Z M70 83 88 109 83 129 62 115Z" fill="#e25b7f"/><path d="M50 8Q22 34 25 82L32 116Q50 125 68 116L75 82Q78 34 50 8Z" fill="url(#rocketMetal)" stroke="#90b4e5" stroke-width="2"/><path d="M50 8Q38 21 32 39L68 39Q62 21 50 8Z" fill="#f16d83"/><circle cx="50" cy="71" r="15" fill="#172e62" stroke="#f2faff" stroke-width="5"/><circle cx="50" cy="71" r="8" fill="#6be3ff"/><path d="M40 111H60V124H40Z" fill="#577eaa"/></svg></div>
      <svg class="flight-path" viewBox="0 0 330 180" preserveAspectRatio="none"><path id="rocketTrail" d="M10 165 Q 110 158 172 95 T 320 24" fill="none" stroke="#63dffb" stroke-width="3" stroke-linecap="round" stroke-dasharray="800" stroke-dashoffset="${phase==='waiting'?800:0}"/></svg>
      <div class="rocket-explosion" id="rocketExplosion"><div class="blast-core"><span class="gl12-burst">✹</span></div><div class="blast-wave"></div><b>РАКЕТА ВЗОРВАЛАСЬ!</b><small>На ${r?.lastCrash?.crashAt?.toFixed(2)||'—'}x</small></div>
      <div class="rocket-metrics"><strong id="rocketMult">${phase==='active'?r.current.toFixed(2):'1.00'}x</strong><span id="rocketStatus" class="mut">${phase==='waiting'?'ПРИЁМ СТАВОК · СТАРТ ЧЕРЕЗ':'РАКЕТА ЛЕТИТ'}</span><div class="rocket-timer" id="rocketTimer">${phase==='waiting'?(Math.ceil((r?.remainingMs||10000)/1000)+' сек.'):''}</div></div>
    </div>
    ${phase==='waiting'?`<h2>Демо-ставка</h2><div class="stake-row">${[25,100,500,1000,5000].map(n=>`<button data-act="stake" data-id="${n}" class="pill ${S.stake===n?'on':''}" ${bet?'disabled':''}>${fmt(n)} ⭐</button>`).join('')}</div>${stakeEntry(bet)}
      <button class="btn full space" data-act="rocket-start" ${bet?'disabled':''}>${bet?`✓ Ставка ${r.stake} ⭐ принята`:`Поставить <span data-stake-label>${fmt(S.stake)}</span> ⭐`}</button><p class="mut sm space">Раунд общий: 10 секунд на ставки, затем полёт. После взрыва начинается новый отсчёт.</p>`:
      bet&&!r.cashed?`<button class="btn full space" data-act="rocket-cash">Забрать <span id="rocketPayout">${Math.round(r.stake*r.current)}</span> ⭐</button>`:
      `<div class="card info-card space">${r?.cashed?`✅ Ты забрал ${r.payout} ⭐. `:'Ставки закрыты — наблюдай за полётом. '}Следующий раунд начнётся после взрыва.</div>`}
    <div class="card info-card space"><b>Rocket · общий демо-раунд</b><p class="mut sm">Полёт синхронизирован с сервером. Взрыв показывается только один раз — прежний взрыв не повторяется при новой ставке.</p></div>`},
  mines(){const r=S.mines;return `${back()}${menuHeader('Mines')}${note}<div class="mines-top card"><div><span class="eyebrow">МНОЖИТЕЛЬ</span><b>${(r?.multiplier||1).toFixed(2)}×</b></div><div><span class="eyebrow">МИНЫ</span><b>${r?.count||S.minerCount} 💣</b></div><div><span class="eyebrow">СТАТУС</span><b class="sm">${r?.status==='active'?'Играем':r?.status==='lost'?'Взрыв':r?.status==='cashed'||r?.status==='won'?'Победа':'Ожидание'}</b></div></div>
  <div class="minefield">${Array.from({length:25},(_,i)=>{const revealed=r?.revealed?.includes(i),bomb=r?.status!=='active'&&r?.mines?.includes(i),isActive=r?.status==='active';return `<button ${!isActive||revealed?'disabled':''} data-act="mine-cell" data-id="${i}" class="mine-cell ${revealed?'open':''} ${bomb?'bomb':''}">${bomb?'💣':revealed?'💎':'✦'}</button>`}).join('')}</div>
  ${r?.status==='active'?`<button class="btn full space" data-act="mines-cash" ${!r.revealed.length?'disabled':''}>Забрать ${Math.round(r.stake*r.multiplier)} ⭐</button>`:
    `<h2>Количество мин</h2><div class="stake-row">${[1,3,5,7,10].map(n=>`<button data-act="mine-count" data-id="${n}" class="pill ${S.minerCount===n?'on':''}">${n} 💣</button>`).join('')}</div><h2>Демо-ставка</h2><div class="stake-row">${[25,100,500,1000,5000].map(n=>`<button data-act="stake" data-id="${n}" class="pill ${S.stake===n?'on':''}">${fmt(n)} ⭐</button>`).join('')}</div>${stakeEntry()}<button class="btn full space" data-act="mines-start">Начать за <span data-stake-label>${fmt(S.stake)}</span> ⭐</button>`}
    <p class="mut sm space">Открывай безопасные клетки и забирай демо-звёзды. Мины генерируются на сервере и скрыты до окончания раунда.</p>`},
  pvp(){const c=S.cases.find(x=>x.id===S.battleCase)||S.cases[0];const room=S.rooms.find(r=>r.id===S.roomId);return `${back()}${menuHeader('Case Battle')}${note}<div class="battle-head">⚔️ <span>ИГРОК</span> <b>VS</b> <span>ИГРОК</span></div>
    <div class="card"><h2 style="margin-top:0">Создать битву</h2><label class="mut sm">Выбрать кейс</label><select id="battleCase" class="select">${S.cases.map(x=>`<option value="${x.id}" ${x.id===S.battleCase?'selected':''}>${esc(x.name)} · ${x.price} ⭐</option>`).join('')}</select><label class="mut sm">Количество раундов</label><div class="stake-row">${[1,3,5].map(n=>`<button class="pill ${S.battleRounds===n?'on':''}" data-act="rounds" data-id="${n}">${n}</button>`).join('')}</div><button class="btn full space" data-act="battle-create">Создать · ${c.price*S.battleRounds} ⭐</button></div>
    <h2>Присоединиться по коду</h2><div class="row"><input class="text-input grow" id="roomCode" placeholder="Код комнаты (8 символов)" maxlength="8" autocapitalize="characters"><button class="btn" data-act="room-code">Войти</button></div>
    ${room?`<h2>Твоя комната #${room.id}</h2>${roomCard(room,true)}`:''}<div class="sectionhead"><h2>Комнаты игроков</h2><button data-act="rooms-refresh">↻ Обновить</button></div><div class="room-list">${S.rooms.filter(r=>r.id!==S.roomId&&r.status==='waiting').slice(0,20).map(r=>roomCard(r)).join('')||empty('⚔️','Пока нет комнат. Создай первую!')}</div>
    <p class="mut sm space">Два реальных участника. Каждый оплачивает одинаковое число кейсов демо-звёздами; оба открывают призы. Победитель по сумме ценностей забирает все виртуальные подарки. Никаких ботов-соперников.</p>`}
};
function roomCard(r,detail=false){const ended=r.status==='finished',isCreator=r.creatorId===S.user.id,hasJoined=r.joinerId===S.user.id;let sum='';if(ended&&r.totals)sum=`<div class="battle-result"><div>${esc(r.creatorName)}<b>${r.totals.creator} ⭐</b></div><span>VS</span><div>${esc(r.joinerName)}<b>${r.totals.joiner} ⭐</b></div></div><div class="winner-label">🏆 Победитель: ${esc(r.winnerName)} · ${r.awardItems||0} подарков</div>${r.rolls?`<div class="rolls">${r.rolls.creator.map((item,i)=>`<div><span>Раунд ${i+1}</span><span>${item.emoji} ${item.value} ⭐</span><span>${r.rolls.joiner[i].emoji} ${r.rolls.joiner[i].value} ⭐</span></div>`).join('')}</div>`:''}`;return `<div class="card room-card"><div class="row sp"><b>⚔️ #${r.id}</b><span class="badge">${ended?'Завершено':r.status==='waiting'?'Ожидание':'Отменено'}</span></div><div class="mut sm">${esc(r.creatorName)} ${r.joinerName?'vs '+esc(r.joinerName):'ждёт соперника'} · ${r.rounds||1} раунд · ${r.stake} ⭐</div>${sum}${r.status==='waiting'?(isCreator?`<div class="row space"><button class="btn alt" data-act="room-copy" data-id="${r.id}">Скопировать код</button><button class="btn alt" data-act="room-cancel" data-id="${r.id}">Отменить</button></div>`:`<button class="btn full space" data-act="room-join" data-id="${r.id}">Вступить за ${r.stake} ⭐</button>`):''}${ended&&(isCreator||hasJoined)?'<div class="mut sm space">Призы победителя находятся в его инвентаре.</div>':''}</div>`}
function render(){if(!S.user)return;const page=S.page||S.tab;$('#view').innerHTML=`<div class="page">${pages[page]()}</div>`;$('#nav').innerHTML=`<div>${TABS.map(([id,label])=>`<button class="${S.tab===id?'on':''}" data-act="tab" data-id="${id}"><svg viewBox="0 0 24 24">${icons[id]}</svg>${label}</button>`).join('')}</div>`;if(tg?.BackButton){S.page?tg.BackButton.show():tg.BackButton.hide()}}
function go(tab){S.tab=tab;S.page='';haptic();render();window.scrollTo(0,0);if(tab==='leaders')loadLeaders();if(tab==='home')loadRecent();if(tab==='cases')refreshCasePrices();}
function openPage(page,id=''){S.page=page;if(page==='case')S.caseId=id;if(page==='pvp')S.roomId='';render();window.scrollTo(0,0);if(page==='pvp')loadRooms();if(page==='rocket'){S.lastRocketPoll=0;loadRocket();}if(page==='mines')loadMines();if(page==='market')loadMarket();if(page==='deposit')loadDeposit();}
function backPage(){if(S.page){S.page='';render()}else go('home')}
async function loadMarket(){try{S.market=await api('/api/market?q='+encodeURIComponent(S.marketQuery));if(S.page==='market')render();}catch(e){notify(e.message)}}
async function refreshCasePrices(){try{S.cases=await api('/api/cases');if(S.tab==='cases'||S.page==='case')render();}catch{}}
async function loadDeposit(){try{const [j,m,c,s]=await Promise.all([api('/api/deposit/history'),api('/api/market'),api('/api/deposit/collections'),api('/api/support/status')]);S.supportStatus=s;S.depositHistory=j.entries||[];S.market=m;S.depositCollections=c.items||[];if(!S.depositCollections.some(x=>x.name===S.depositCollection))S.depositCollection=S.depositCollections[0]?.name||'';if(S.page==='deposit')render()}catch(e){notify(e.message)}}
async function depositQuote(method){try{let url='/api/deposit/quote?method='+method;
 if(method==='nft')url+='&collection='+encodeURIComponent(S.depositCollection);else url+='&amount='+encodeURIComponent(S.depositAmount);
 S.depositQuote=await api(url);if(S.page==='deposit')render();}catch(e){notify(e.message)}}
async function loadMarketQuote(){try{S.marketQuote=await api('/api/market/quote?ton='+encodeURIComponent(S.quoteTon));if(S.page==='market')render();}catch(e){notify(e.message)}}
async function refreshMe(){S.user=(await api('/api/me')).user;render();}
async function loadLeaders(){try{const d=await api('/api/leaders?period='+S.period+'&metric='+S.metric);S.leaders=d.leaders;S.mine=d.mine;if(S.tab==='leaders'&&!S.page)render();}catch(e){notify(e.message)}}
async function loadRecent(){try{S.recent=(await api('/api/recent')).recent;if(S.tab==='home'&&!S.page)render()}catch{}}
async function loadRooms(){try{S.rooms=(await api('/api/rooms')).rooms;if(S.page==='pvp')render()}catch(e){notify(e.message)}}
async function loadRocket(){try{S.rocket=(await api('/api/rocket/state')).round;lastRocketCrashSeen=S.rocket.lastCrash?.id||null;rocketEnteredAt=Date.now();if(S.page==='rocket')render()}catch(e){notify(e.message)}}
async function loadMines(){try{S.mines=(await api('/api/mines/state')).round;if(S.page==='mines')render()}catch(e){notify(e.message)}}
function spinItem(i){return `<div class="rc" style="--c:${color[i.r?.toLowerCase()]||color[i.rarity]||'#a78bfa'}">${itemArt({rarity:i.r?.toLowerCase()||i.rarity,image:i.image,emoji:i.e||i.emoji})}<b>${esc(i.n||i.name)}</b><span class="sm">${i.value} ⭐</span></div>`}
const pickDecoration=items=>{let n=Math.random()*100;for(const i of items){n-=i.p;if(n<=0)return i}return items[0]};
function wait(ms){return new Promise(resolve=>setTimeout(resolve,ms))}
function randId(){return window.crypto.randomUUID()}
async function openCase(id){if(S.busy)return;S.busy=true;const c=S.cases.find(x=>x.id===id);const count=S.caseCount||1;
 try{const r=await serverPost('/api/cases/open',{caseId:id,count,requestId:randId()});S.user=r.user;
 const winners=r.items.map(it=>({e:it.emoji,image:it.image,n:it.name,r:it.rarity,value:it.value,kind:it.kind,instanceId:it.instanceId}));
 const WIN=29,PITCH=112;const overlay=document.createElement('div');overlay.className='ov multi-case-ov';
 overlay.innerHTML=`<div class="ov-in"><span class="eyebrow">${esc(c.name)} · ${count} открытия одновременно</span><h2>Что выпадет?</h2><div class="all-roulettes">${winners.map((prize,k)=>`<div class="roul compact-roul"><span class="roul-no">#${k+1}</span><div class="ptr"></div><div class="track">${Array.from({length:38},(_,i)=>spinItem(i===WIN?prize:pickDecoration(c.items))).join('')}</div></div>`).join('')}</div><div class="result-slot" aria-live="polite"></div></div>`;
 document.body.appendChild(overlay);const rows=[...overlay.querySelectorAll('.roul')];
 await Promise.all(rows.map(async(row,k)=>{const track=row.querySelector('.track');const move=WIN*PITCH+52-row.clientWidth/2;
 try{await track.animate([{transform:'translateX(0px)'},{transform:`translateX(${-move}px)`}],{duration:S.set.fast?700:4400+90*k,easing:'cubic-bezier(.10,.75,.09,1)',fill:'forwards'}).finished}catch{}
 track.children[WIN].classList.add('win');}));
 const totalValue=winners.reduce((v,x)=>v+x.value,0),win=totalValue>r.spent;
 overlay.querySelector('.result-slot').innerHTML=`<div class="result-card compact-results"><h2>${win?'✦ Отличный дроп!':'Результаты открытия'}</h2><div class="prize-summary">${winners.map(w=>`<div>${itemArt({rarity:w.r,image:w.image,emoji:w.e})}<b>${esc(w.n)}</b><small>${fmt(w.value)} ⭐${w.kind==='stars'?' · на баланс':''}</small></div>`).join('')}</div><p class="mut sm">Ценность ${fmt(totalValue)} ⭐ · потрачено ${fmt(r.spent)} ⭐</p><button id="result-close" class="btn full space">Продолжить</button></div>`;
 if(win||winners.some(w=>w.kind==='collectible-preview'))sparkle(overlay,Math.min(25,10+count*5));
 overlay.querySelector('#result-close').onclick=()=>{overlay.remove();S.busy=false;render();loadRecent()};
 }catch(e){S.busy=false;notify(e.message)}
}
function sparkle(parent,n=18){const conf=document.createElement('div');conf.className='sparkle-layer';for(let i=0;i<n;i++){const dot=document.createElement('i');dot.style.cssText=`--x:${Math.random()*100}%;--d:${(Math.random()*1.7).toFixed(2)}s;--s:${(Math.random()*70-35).toFixed(0)}px`;conf.appendChild(dot);}parent.appendChild(conf);setTimeout(()=>conf.remove(),2500)}
async function doUpgrade(){if(S.busy)return;const inv=S.user.inventory,ids=S.sourceIds.filter(id=>inv.some(x=>x.instanceId===id));const extra=S.upgradeStars||0;
 const total=ids.reduce((a,id)=>a+(inv.find(x=>x.instanceId===id)?.value||0),0)+extra;
 const targets=S.catalog.filter(x=>x.kind!=='stars'&&x.value>total).sort((a,b)=>a.value-b.value);const target=targets.find(x=>x.id===S.targetId)||targets[0];
 if(!total||!target)return notify('Выбери до 3 подарков или добавь звёзды, затем выбери цель');S.busy=true;
 try{const data=await serverPost('/api/upgrade',{instanceIds:ids,stars:extra,targetId:target.id});
 const area=$('#upgradeMotion'),needle=$('#spinNeedle'),cta=$('#upgradeCTA');if(!area||!needle)throw new Error('Экран апгрейда недоступен');
 cta.disabled=true;area.classList.add('is-spinning');const chanceDeg=data.chance*360;const landing=data.success?Math.max(3,Math.random()*Math.max(4,chanceDeg-7)):chanceDeg+5+Math.random()*Math.max(4,354-chanceDeg);
 const animation=needle.animate([{transform:'translateX(-50%) rotate(0deg)'},{transform:`translateX(-50%) rotate(${2160+landing}deg)`}],{duration:S.set.fast?1250:3300,easing:'cubic-bezier(.12,.72,.11,1)',fill:'forwards'});
 try{await animation.finished}catch{}
 S.user=data.user;S.sourceIds=[];S.upgradeStars=0;S.targetId='';area.classList.remove('is-spinning');
 $('#upgradeResultInline').innerHTML=`<div class="result-card inline-up-result"><div class="${data.success?'win-text':'lose-text'}">${data.success?'✦ АПГРЕЙД УСПЕШЕН!':'✕ НЕ УДАЛОСЬ'}</div><b>${data.success?esc(target.name)+' · '+fmt(target.value)+' ⭐':'Твоя попытка завершилась неудачей'}</b><p class="mut sm">Вклад: ${fmt(data.sourceValue)} ⭐ · ${(data.chance*100).toFixed(2)}%</p><button id="upgradeContinue" class="btn alt full space">Продолжить</button></div>`;
 if(data.success)sparkle(area,18);
 $('#upgradeContinue').onclick=()=>{S.busy=false;render();window.scrollTo({top:0,behavior:'smooth'})};
 }catch(e){S.busy=false;notify(e.message)}
}
async function actRun(fn){if(S.busy)return;S.busy=true;try{await fn()}catch(e){notify(e.message)}finally{S.busy=false}}
async function changeUser(r){if(r?.user)S.user=r.user;render()}
document.addEventListener('error',e=>{if(e.target?.matches?.('img.tg-gift-img')){e.target.style.display='none';const fallback=e.target.nextElementSibling;if(fallback)fallback.style.display='block';}},true);
function readStake(){
 const input=$('#customStake');
 const raw=input?input.value.trim():String(S.stake);
 if(!/^\d+$/.test(raw))throw new Error('Введите целое число демо-звёзд');
 const value=Number(raw);
 if(!Number.isSafeInteger(value)||value<1||value>100000)throw new Error('Введите от 1 до 100 000 демо-звёзд');
 S.stake=value;
 return value;
}
document.addEventListener('input',e=>{
 if(e.target.id==='customStake'){
  const el=document.querySelector('[data-stake-label]');
  if(el)el.textContent=fmt(e.target.value||0);
 }
});
document.addEventListener('change',e=>{if(e.target.id==='depositCollection'){S.depositCollection=e.target.value;S.depositQuote=null;render()}if(e.target.id==='depositAmount'){S.depositAmount=e.target.value;S.depositQuote=null;}if(e.target.id==='leaderMetric'){S.metric=e.target.value;loadLeaders()}if(e.target.id==='battleCase'){S.battleCase=e.target.value;render()}if(e.target.id==='upgradeStars'){const n=Number(e.target.value);if(!Number.isSafeInteger(n)||n<0||n>Math.min(S.user.balance,100000)){notify('Введи допустимую сумму звёзд');e.target.value=S.upgradeStars}else{S.upgradeStars=n;S.targetId='';render()}}});
document.addEventListener('click',async e=>{
 const b=e.target.closest('[data-act]');if(!b||!S.user)return;const {act,id}=b.dataset;
 if(act==='reload')return location.reload();
 if(act==='market')return openPage('market');
 if(act==='deposit')return openPage('deposit');
 if(act==='buy-supporter')return actRun(async()=>{
   if(!tg?.openInvoice)throw Error('Открой GiftLab в Telegram Mini App');
   const data=await serverPost('/api/support/invoice',{});
   tg.openInvoice(data.invoiceUrl,async status=>{notify(status==='paid'?'Telegram подтвердил оплату, проверяем доставку значка…':'Статус Telegram: '+status);setTimeout(async()=>{try{S.supportStatus=await api('/api/support/status');S.user=(await api('/api/me')).user;render()}catch{}},1800)});
 });
 if(act==='deposit-mode'){S.depositMethod=id;S.depositQuote=null;S.depositAmount=id==='ton'?'1':'500';return render()}
 if(act==='deposit-preset'){S.depositAmount=id;S.depositQuote=null;return render()}
 if(act==='deposit-history')return loadDeposit();
 if(act==='deposit-search'){S.depositSearch=$('#depositSearch')?.value?.trim()||'';return render()}
 if(act==='deposit-nft-pick'){S.depositCollection=id;S.depositQuote=null;return render()}
 if(act==='deposit-quote')return depositQuote('ton');
 if(act==='deposit-nft-quote')return depositQuote('nft');
 if(act==='deposit-sandbox-credit')return actRun(async()=>{const amount=Number($('#depositAmount')?.value);if(!Number.isSafeInteger(amount)||amount<1||amount>50000)throw Error('Введите от 1 до 50 000');const r=await serverPost('/api/deposit/sandbox-credit',{amount,requestId:randId()});S.user=r.user;notify(`Тестовое начисление +${fmt(r.entry.credited)} ⭐ после демо-комиссии`);await loadDeposit()});
 if(act==='deposit-nft-request')return actRun(async()=>{const r=await serverPost('/api/deposit/nft-sandbox-request',{collection:S.depositCollection,requestId:randId()});notify('Тестовая заявка '+r.entry.id.slice(0,8)+' создана');await loadDeposit()});
 if(act==='market-refresh')return loadMarket();
 if(act==='market-search'){S.marketQuery=$('#marketSearch')?.value?.trim()||'';return loadMarket()}
 if(act==='market-quote'){S.quoteTon=$('#marketTon')?.value?.trim()||'1';return loadMarketQuote()}
 if(act==='tab')return go(id);
 if(act==='back')return backPage();
 if(act==='case')return openPage('case',id);
 if(act==='game')return openPage(id);
 if(act==='period'){S.period=id;render();return loadLeaders()}
 if(act==='refresh-recent')return loadRecent();
 if(act==='case-count'){S.caseCount=Number(id);return render()}
 if(act==='toggle-fast'){S.set.fast=!S.set.fast;localStorage.setItem('gl_settings',JSON.stringify(S.set));return render()}
 if(act==='open')return openCase(id);
 if(act==='claim')return actRun(async()=>changeUser(await serverPost('/api/demo-stars')));
 if(act==='sell')return actRun(async()=>{const item=S.user.inventory.find(x=>x.instanceId===id);if(!item||!confirm(`Продать ${item.name} за ${item.value} демо-звёзд?`))return;const r=await serverPost('/api/inventory/sell',{instanceId:id});notify(`Продано за ${r.payout} ⭐`);changeUser(r)});
 if(act==='sell-all')return actRun(async()=>{const count=S.user.inventory.length;const total=S.user.inventory.reduce((s,i)=>s+i.value,0);if(!count)return notify('Инвентарь пуст');if(!confirm(`Продать все ${count} подарков за ${fmt(total)} демо-звёзд?`))return;const r=await serverPost('/api/inventory/sell-all',{});notify(`Продано ${r.count} подарков за ${fmt(r.payout)} ⭐`);changeUser(r)});
 if(act==='source-toggle'){if(S.sourceIds.includes(id))S.sourceIds=S.sourceIds.filter(x=>x!==id);else if(S.sourceIds.length<3)S.sourceIds=[...S.sourceIds,id];else return notify('Можно выбрать максимум 3 подарка');S.targetId='';return render()}
 if(act==='target'){S.targetId=id;return render()}
 if(act==='upgrade-spin')return doUpgrade();
 if(act==='stake'){S.stake=Number(id);return render()}
 if(act==='case-filter'){S.caseFilter=id;return render()}
 if(act==='mine-count'){S.minerCount=Number(id);return render()}
 if(act==='rocket-start')return actRun(async()=>{const r=await serverPost('/api/rocket/start',{stake:readStake()});S.rocket=r.round;changeUser(r);notify('Ставка принята! Ждём общий старт 🚀')});
 if(act==='rocket-cash')return actRun(async()=>{const r=await serverPost('/api/rocket/cashout');S.rocket=r.round;notify(`Забрано ${r.round.payout} ⭐`);changeUser(r)});
 if(act==='mines-start')return actRun(async()=>{const r=await serverPost('/api/mines/start',{stake:readStake(),count:S.minerCount});S.mines=r.round;changeUser(r)});
 if(act==='mine-cell')return actRun(async()=>{const r=await serverPost('/api/mines/reveal',{cell:Number(id)});S.mines=r.round;changeUser(r);if(r.hit)notify('💣 Мина! Раунд завершён')});
 if(act==='mines-cash')return actRun(async()=>{const r=await serverPost('/api/mines/cashout');S.mines=r.round;notify(`Забрано ${r.round.payout} ⭐`);changeUser(r)});
 if(act==='rounds'){S.battleRounds=Number(id);return render()}
 if(act==='battle-create')return actRun(async()=>{const r=await serverPost('/api/rooms/create',{caseId:S.battleCase,rounds:S.battleRounds});S.roomId=r.room.id;S.rooms.unshift(r.room);changeUser(r);notify('Комната создана — отправь код другу')});
 if(act==='room-code'){const code=$('#roomCode')?.value.trim().toUpperCase();if(!/^[A-F0-9]{8}$/.test(code))return notify('Нужен код из 8 символов');return joinRoom(code)}
 if(act==='room-join')return joinRoom(id);
 if(act==='room-copy'){try{await navigator.clipboard.writeText(id);notify('Код комнаты скопирован')}catch{prompt('Скопируй код комнаты:',id)}return}
 if(act==='room-cancel')return actRun(async()=>{const r=await serverPost(`/api/rooms/${id}/cancel`);S.rooms=S.rooms.map(x=>x.id===id?r.room:x);changeUser(r);notify('Комната отменена')});
 if(act==='rooms-refresh')return loadRooms();
});
// PvP visuals only: both sides' prizes and winner are precomputed and persisted on the server.
const animatedBattles=new Set();
async function showBattleAnimation(room){
 if(!room?.rolls||animatedBattles.has(room.id))return;
 animatedBattles.add(room.id);
 const overlay=document.createElement('div');overlay.className='ov battle-ov';
 overlay.innerHTML=`<div class="ov-in"><span class="eyebrow">CASE BATTLE · #${room.id}</span><h1 class="space">${esc(room.creatorName)} <span class="mut">VS</span> ${esc(room.joinerName)}</h1><div class="battle-live"><div><b>${esc(room.creatorName)}</b><div id="pvpLeft"></div><strong id="pvpSumLeft">0 ⭐</strong></div><div class="battle-mid">VS</div><div><b>${esc(room.joinerName)}</b><div id="pvpRight"></div><strong id="pvpSumRight">0 ⭐</strong></div></div><div id="pvpFinal"><span class="mut">Открываем кейсы...</span></div></div>`;
 document.body.appendChild(overlay);
 let left=0,right=0;
 for(let i=0;i<room.rolls.creator.length;i++){
  if(!overlay.isConnected)return;
  const a=room.rolls.creator[i],b=room.rolls.joiner[i];left+=a.value;right+=b.value;
  overlay.querySelector('#pvpLeft').innerHTML+=`<div class="battle-drop">${itemArt(a)}<small>Раунд ${i+1}</small><b>${a.value} ⭐</b></div>`;
  overlay.querySelector('#pvpRight').innerHTML+=`<div class="battle-drop">${itemArt(b)}<small>Раунд ${i+1}</small><b>${b.value} ⭐</b></div>`;
  overlay.querySelector('#pvpSumLeft').textContent=left+' ⭐';overlay.querySelector('#pvpSumRight').textContent=right+' ⭐';
  await wait(700);
 }
 overlay.querySelector('#pvpFinal').innerHTML=`<div class="result-card"><div class="win-text">🏆 ПОБЕДИТЕЛЬ</div><h2>${esc(room.winnerName)}</h2><p class="mut sm">Все ${room.awardItems} подарков и ${room.awardStars||0} ⭐ зачислены победителю.</p><button id="pvpClose" class="btn full space">К списку боёв</button></div>`;
 overlay.querySelector('#pvpClose').onclick=()=>{overlay.remove();render()};
}
function joinRoom(id){return actRun(async()=>{const r=await serverPost(`/api/rooms/${id}/join`);S.roomId=id;S.rooms=S.rooms.filter(x=>x.id!==id).concat(r.room);changeUser(r);showBattleAnimation(r.room)})}
let lastRocketCrashSeen=null,rocketEnteredAt=0;
setInterval(async()=>{
 if(S.page==='rocket'&&S.rocket){
  const r=S.rocket,now=Date.now();
  if(r.status==='waiting'){
    const remain=Math.max(0,r.startAt-now),timer=$('#rocketTimer');
    if(timer)timer.textContent=(remain/1000).toFixed(1)+' сек.';
    const label=$('#rocketStatus');if(label)label.textContent='ПРИЁМ СТАВОК · СТАРТ ЧЕРЕЗ';
  }else if(r.status==='active'){
    const current=Math.exp(Math.max(0,now-r.started)/9000);
    const label=$('#rocketMult');if(label)label.textContent=current.toFixed(2)+'x';
    const payout=$('#rocketPayout');if(payout)payout.textContent=fmt(Math.round(r.stake*current));
    const ship=$('#rocketShip');if(ship){const progress=Math.min(1,Math.log(Math.max(1,current))/Math.log(8));const bounds=ship.parentElement.getBoundingClientRect();const x=Math.max(0,bounds.width-125)*.85*progress;const y=-Math.max(0,bounds.height-168)*.66*progress;ship.style.transform=`translate3d(${Math.round(x)}px,${Math.round(y)}px,0) rotate(29deg)`;}
    const trail=$('#rocketTrail');if(trail)trail.style.strokeDashoffset=Math.max(0,800-180*Math.max(0,current-1));
  }
  if(!S.lastRocketPoll||now-S.lastRocketPoll>380){
    S.lastRocketPoll=now;
    try{
      const d=await api('/api/rocket/state'),next=d.round;
      if(next.lastCrash && next.lastCrash.id!==lastRocketCrashSeen && next.lastCrash.at>=rocketEnteredAt-300 && now-next.lastCrash.at<1700){
        lastRocketCrashSeen=next.lastCrash.id;
        S.rocket=next;render();
        const stage=$('#rocketStage');if(stage){stage.classList.add('crashed');setTimeout(()=>{stage.classList.remove('crashed')},1500);try{tg?.HapticFeedback?.notificationOccurred('error')}catch{}}
      }else if(next.id!==r.id||next.status!==r.status||next.hasBet!==r.hasBet||next.cashed!==r.cashed){S.rocket=next;render();}
      else S.rocket=next;
    }catch{}
  }
 }
 if(S.page==='pvp'&&(!S.lastRoomPoll||Date.now()-S.lastRoomPoll>2800)){
 S.lastRoomPoll=Date.now();try{const rooms=(await api('/api/rooms')).rooms;const prev=S.rooms.find(r=>r.id===S.roomId),next=rooms.find(r=>r.id===S.roomId);S.rooms=rooms;if(next&&prev?.status!==next.status){if(next.status==='finished'){S.user=(await api('/api/me')).user;notify('Твой PvP завершился!');showBattleAnimation(next)}render()}}catch{}
 }
},180);
(async()=>{
 try{if(tg){tg.ready();tg.expand();try{tg.setHeaderColor('#06110d');tg.setBackgroundColor('#06110d')}catch{}tg.BackButton?.onClick(backPage)}
 $('#view').innerHTML='<div class="card empty" style="margin-top:36px"><i>🎁</i>Загрузка GiftLab…</div>';
 const dev=new URLSearchParams(location.search).get('dev');const identity=tg?.initData?{initData:tg.initData}:{demoName:dev==='2'?'Витёк':'Яблочко'};
 const r=await fetch('/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(identity)});const a=await r.json();if(!r.ok)throw new Error(a.error||'Не удалось войти');
 S.user=a.user;S.token=a.token;const [cases,catalog,support]=await Promise.all([api('/api/cases'),api('/api/catalog'),api('/api/support/config')]);S.supportConfig=support;S.cases=cases;S.catalog=catalog.items;S.isLocalDemo=Boolean(catalog.demo);render();loadRecent();
 }catch(e){$('#view').innerHTML=`<div class="card empty" style="margin-top:40px"><i>⚠️</i>${esc(e.message)}<p class="mut sm">Проверь запуск сервера. Для Telegram требуется HTTPS и BOT_TOKEN.</p><button class="btn" onclick="location.reload()">Повторить</button></div>`}
})();
