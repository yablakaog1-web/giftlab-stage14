'use strict';
// Official XTR purchase of a NON-REDEEMABLE digital profile badge.
// This deliberately never increases gaming/demo-star balance and is not a gambling deposit.
const crypto = require('node:crypto');
const PRODUCT = Object.freeze({id:'lab-supporter-v1',price:25,currency:'XTR',title:'Lab Supporter',description:'Постоянный цифровой значок поддержки лаборатории GiftLab. Не является игровой валютой, NFT или ставкой.'});
const idPattern=/^support:([a-f0-9-]{36})$/i;
function startOrder(state,user,now=Date.now()) {
  if(!/^tg:\d+$/.test(String(user.id||''))) throw Error('Покупка доступна только с подтверждённым входом Telegram');
  if(user.labSupporter) throw Error('Значок уже приобретён');
  state.supportOrders||={};
  const pending=Object.values(state.supportOrders).find(o=>o.userId===user.id&&o.status==='pending'&&now-o.createdAt<15*60*1000);
  if(pending)return pending;
  const id=crypto.randomUUID();
  const o={id,userId:user.id,telegramId:Number(user.id.slice(3)),status:'pending',createdAt:now,productId:PRODUCT.id,amount:PRODUCT.price,currency:PRODUCT.currency};
  state.supportOrders[id]=o;return o;
}
function precheckout(state,q,now=Date.now()) {
  const id=idPattern.exec(String(q?.invoice_payload||''))?.[1];
  const o=id&&state.supportOrders?.[id];
  const valid=!!(o&&o.status==='pending'&&now-o.createdAt<15*60*1000&&o.productId===PRODUCT.id&&o.currency===PRODUCT.currency&&o.amount===PRODUCT.price&&q.currency===PRODUCT.currency&&q.total_amount===o.amount&&Number(q.from?.id)===o.telegramId);
  return {ok:valid,error_message:valid?undefined:'Заказ поддержки не найден, изменён или просрочен. Откройте новый счёт.'};
}
function settle(state,message,now=Date.now()) {
  const payment=message?.successful_payment;
  if(!payment)return {accepted:false,reason:'no-payment'};
  const id=idPattern.exec(String(payment.invoice_payload||''))?.[1];
  const o=id&&state.supportOrders?.[id];
  const charge=String(payment.telegram_payment_charge_id||'');
  state.supportCharges||={};
  if(charge&&state.supportCharges[charge])return {accepted:false,duplicate:true};
  if(!o||!charge||payment.currency!==PRODUCT.currency||payment.total_amount!==o.amount||o.productId!==PRODUCT.id||Number(message.from?.id)!==o.telegramId)return {accepted:false,reason:'mismatch'};
  if(o.status!=='pending')return {accepted:false,reason:'not-pending'};
  const user=state.users[o.userId];if(!user)return {accepted:false,reason:'no-user'};
  state.supportCharges[charge]=o.id;
  o.status='paid';o.paidAt=now;o.chargeId=charge;
  user.labSupporter=true;
  return {accepted:true,userId:o.userId,orderId:o.id};
}
module.exports={PRODUCT,startOrder,precheckout,settle};
