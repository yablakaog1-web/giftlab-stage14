@echo off
cd /d "%~dp0"
where node >nul 2>nul || (echo Install Node.js 20+ from https://nodejs.org && pause && exit /b 1)
set PORT=3024
echo Starting GIFT LAB Stage 14 demo on http://localhost:3024
node server.js
pause
