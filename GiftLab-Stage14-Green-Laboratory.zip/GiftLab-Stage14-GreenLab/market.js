'use strict';
/** GiftLab Market Observer: public, read-only pricing and simulation. No blockchain transfers. */
const fs=require('node:fs');
const path=require('node:path');
const SOURCE='https://tggifts.com/data/floors-daily.json';
const RATE_SOURCE='https://api.coingecko.com/api/v3/simple/price?ids=the-open-network&vs_currencies=usd&include_last_updated_at=true';
const THIRDPARTY=[
 {name:'TON Gifts Wiki',url:'https://tongifts.wiki/en',kind:'catalogue only; no verified public floor API'},
 {name:'gifts.supply',url:'https://gifts.supply/catalog',kind:'catalogue only; no verified public floor API'},
 {name:'Gift Loot',url:'https://gift-loot.com/gift/en/',kind:'collection catalogue; founding Stars prices are not floors'},
 {name:'Getgems',url:'https://getgems.io/',kind:'marketplace; official API requires a verified key for reliable reads'},
 {name:'TG Gifts',url:'https://tggifts.com/data',kind:'daily observed collection floors from Fragment; CC BY 4.0'}
];
const num=x=>typeof x==='number'&&Number.isFinite(x)?x:typeof x==='string'&&x.trim()!==''&&Number.isFinite(Number(x))?Number(x):null;
const isDate=d=>/^\d{4}-\d{2}-\d{2}$/.test(d)&&!Number.isNaN(Date.parse(d+'T00:00:00Z'));
const norm=s=>String(s||'').toLowerCase().replace(/[^a-z0-9]/g,'');
// TG Gifts publishes English collection plurals (Snow Globes) while the
// in-app collectible is named in the singular (Snow Globe).
const collectionKey=s=>norm(s).replace(/ies$/,'y').replace(/s$/,'');
function parseDaily(raw,now=Date.now()){
 if(!raw||typeof raw!=='object'||!raw.collections||typeof raw.collections!=='object') throw Error('Invalid floors data schema');
 const parsed=[];
 for(const [slug,obj] of Object.entries(raw.collections)){
  if(!obj||!Array.isArray(obj.days)||!obj.days.length)continue;
  const days=obj.days.map(d=>Array.isArray(d)?{date:d[0],value:num(d[1])}:d&&typeof d==='object'?{date:d.date,value:num(d.floor_gram)}:null)
    .filter(x=>x&&isDate(x.date)&&x.value!==null&&x.value>0&&x.value<1e9&&Date.parse(x.date+'T00:00:00Z')<=now+86400000)
    .sort((a,b)=>a.date.localeCompare(b.date));
  if(!days.length)continue;
  const last=days[days.length-1];
  // Daily source: floor is first observation of day, NOT a live executable offer.
  parsed.push({slug:norm(slug),name:String(obj.name||slug).slice(0,90),floorTon:String(last.value),observationDate:last.date,
   source:'TG Gifts / Fragment',sourceUrl:SOURCE,kind:'daily-open-floor',stale:now-Date.parse(last.date+'T00:00:00Z')>48*3600000});
 }
 return parsed;
}
// Money math uses BigInt fixed units, no binary float in conversion/bonus operations.
function decimalToUnits(value,scale=8){
 const str=String(value??'').trim();
 if(!/^\d{1,16}(?:\.\d{1,16})?$/.test(str))throw Error('Введите корректное неотрицательное число');
 const [whole,frac='']=str.split('.');if(frac.length>scale)throw Error('Слишком много знаков после запятой');
 return BigInt(whole)*10n**BigInt(scale)+BigInt(frac.padEnd(scale,'0'));
}
function unitsToDecimal(value,scale=8,maxDecimals=4){
 const neg=value<0n;const a=neg?-value:value;const s=10n**BigInt(scale);const int=a/s;const rem=(a%s).toString().padStart(scale,'0').slice(0,maxDecimals).replace(/0+$/,'');return (neg?'-':'')+int.toString()+(rem?'.'+rem:'');
}
function quote(depositTon,tonUsd,starUsd){
 const ton=decimalToUnits(depositTon);if(ton===0n||ton>100000n*100000000n)throw Error('Демо-сумма должна быть больше 0 и не выше 100 000 TON');
 const bonus=ton*5n/100n;
 const out={kind:'simulation',realPaymentsEnabled:false,amountTon:unitsToDecimal(ton,8,8),bonusTon:unitsToDecimal(bonus,8,8),totalTon:unitsToDecimal(ton+bonus,8,8),bonusPercent:5};
 if(tonUsd&&starUsd){
  const usd=decimalToUnits(tonUsd),star=decimalToUnits(starUsd);
  if(usd>0n&&star>0n){
   const base=ton*usd/star; // internal Stars, 8 decimal places
   const extra=base*5n/100n;
   out.tonUsd=String(tonUsd);out.internalStarUsd=String(starUsd);
   out.baseInternalStars=unitsToDecimal(base);out.bonusInternalStars=unitsToDecimal(extra);out.totalInternalStars=unitsToDecimal(base+extra);
   out.starRateBasis='DEMO_STAR_USD (internal estimate, NOT official Telegram Stars)';
  }
 }
 return out;
}
function discountFloor(floorTon,ratePercent=7){
 const n=decimalToUnits(floorTon),r=BigInt(ratePercent);
 if(r<0n||r>=100n)throw Error('Invalid discount');
 return unitsToDecimal(n*(100n-r)/100n,8,8);
}
class MarketObserver{
 constructor({fetchFn=globalThis.fetch,clock=()=>Date.now(),cacheDir=null,starUsd=process.env.DEMO_STAR_USD||null}={}){
  this.fetchFn=fetchFn;this.clock=clock;this.cacheDir=cacheDir;this.starUsd=starUsd;
  if(starUsd!==null) {const v=decimalToUnits(starUsd);if(v===0n)throw Error('DEMO_STAR_USD must be positive');}
  this.prices=[];this.rate=null;this.lastFloorsAt=null;this.lastRatesAt=null;this.errors=[];this.timer=null;
  this.load();
 }
 load(){if(!this.cacheDir)return;try{const d=JSON.parse(fs.readFileSync(path.join(this.cacheDir,'market-cache.json'),'utf8'));if(Array.isArray(d.prices))this.prices=d.prices.map(p=>({...p,stale:true}));if(d.rate)this.rate={...d.rate,stale:true};this.lastFloorsAt=d.lastFloorsAt||null;this.lastRatesAt=d.lastRatesAt||null;}catch{}}
 save(){if(!this.cacheDir)return;try{fs.mkdirSync(this.cacheDir,{recursive:true});const target=path.join(this.cacheDir,'market-cache.json');const tmp=target+'.tmp';fs.writeFileSync(tmp,JSON.stringify({prices:this.prices,rate:this.rate,lastFloorsAt:this.lastFloorsAt,lastRatesAt:this.lastRatesAt}),{mode:0o600});fs.renameSync(tmp,target);}catch(e){this.addError('cache',e.message);}}
 addError(source,message){this.errors=[{source,message:String(message).slice(0,200),at:new Date(this.clock()).toISOString()},...this.errors].slice(0,10);}
 async fetchJson(url){const c=new AbortController();const t=setTimeout(()=>c.abort(),8000);try{const response=await this.fetchFn(url,{signal:c.signal,headers:{'Accept':'application/json'}});if(!response.ok)throw Error('HTTP '+response.status);return await response.json();}finally{clearTimeout(t);}}
 async updateFloors(){
  try{
   const raw=await this.fetchJson(SOURCE),now=this.clock(),items=parseDaily(raw,now);
   if(!items.length)throw Error('Upstream returned no valid collections');
   const old=new Map(this.prices.map(p=>[p.slug,p]));
   for(const p of items){const previous=old.get(p.slug);if(previous&&Number(previous.floorTon)>0){const ratio=Number(p.floorTon)/Number(previous.floorTon);if((ratio>5||ratio<0.2)&&p.observationDate!==previous.observationDate){this.addError('floor anomaly',p.slug+' changed '+ratio.toFixed(2)+'×; price quarantined');continue;}}old.set(p.slug,p);}
   this.prices=[...old.values()].sort((a,b)=>a.name.localeCompare(b.name));this.lastFloorsAt=new Date(now).toISOString();this.save();return true;
  }catch(e){this.addError('floors',e.message);return false;}
 }
 async updateRates(){
  try{
   const raw=await this.fetchJson(RATE_SOURCE),v=num(raw?.['the-open-network']?.usd),updated=raw?.['the-open-network']?.last_updated_at;
   if(!v||v<=0||v>100000)throw Error('Invalid TON/USD rate');
   if(updated && Math.abs(this.clock()-updated*1000)>60*60*1000)throw Error('TON/USD rate is stale');
   this.rate={tonUsd:String(v),updatedAt:new Date((updated||Math.floor(this.clock()/1000))*1000).toISOString(),source:'CoinGecko',stale:false};this.lastRatesAt=new Date(this.clock()).toISOString();this.save();return true;
  }catch(e){this.addError('TON/USD',e.message);return false;}
 }
 start(){this.updateFloors();this.updateRates();const floorTimer=setInterval(()=>this.updateFloors(),30*60000);const rateTimer=setInterval(()=>this.updateRates(),5*60000);floorTimer.unref?.();rateTimer.unref?.();this.timer=[floorTimer,rateTimer];}
 stop(){(this.timer||[]).forEach(clearInterval);this.timer=null;}
 giftFloor(name){
  const slug=collectionKey(name),p=this.prices.find(x=>collectionKey(x.slug)===slug||collectionKey(x.name)===slug);
  if(!p)return {available:false,status:'unavailable',source:null,observedAt:null,floorTon:null};
  const stale=p.stale||this.clock()-Date.parse(p.observationDate+'T00:00:00Z')>48*3600000;
  return {available:!stale,status:stale?'stale':'observed',source:p.source,observedAt:p.observationDate,floorTon:stale?null:p.floorTon,referenceUrl:p.sourceUrl};
 }
 view(query=''){
  const now=this.clock(),q=norm(query);
  const items=this.prices.filter(p=>!q||norm(p.name).includes(q)||p.slug.includes(q)).slice(0,150).map(p=>{
   const stale=p.stale||now-Date.parse(p.observationDate+'T00:00:00Z')>48*3600000;
   const rateStale=!this.rate||this.rate.stale||now-Date.parse(this.rate.updatedAt)>60*60*1000;
   let internalStars=null;
   if(!stale&&!rateStale&&this.starUsd){try{internalStars=quote(p.floorTon,this.rate.tonUsd,this.starUsd).baseInternalStars;}catch{}}
   return {...p,stale,internalStars};
  });
  return {kind:'read-only-market-demo',source:SOURCE,attribution:'Data: TG Gifts (tggifts.com)',floorType:'daily open; not executable live order',asOf:this.lastFloorsAt,rate:this.rate?{...this.rate,stale:this.rate.stale||now-Date.parse(this.rate.updatedAt)>3600000}:null,starUsd:this.starUsd?'configured DEMO_STAR_USD':'not configured',sources:THIRDPARTY,items,total:this.prices.length,errors:this.errors.slice(0,3),realPaymentsEnabled:false};
 }
 estimate(amount){const rate=this.rate&&!this.rate.stale&&this.clock()-Date.parse(this.rate.updatedAt)<3600000?this.rate.tonUsd:null;return quote(amount,rate,this.starUsd);}
}
module.exports={MarketObserver,parseDaily,quote,discountFloor,decimalToUnits,unitsToDecimal};
