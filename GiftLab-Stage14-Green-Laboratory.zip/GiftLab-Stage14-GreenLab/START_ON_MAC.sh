#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo 'Node.js 20+ не установлен: https://nodejs.org'
  exit 1
fi
export PORT="${PORT:-3024}"
echo "Starting GiftLab Stage 14 · Green Laboratory on http://localhost:$PORT"
echo 'Игры работают только на демо-звёздах. Для Telegram Stars в этом режиме реальные платежи выключены.'
node server.js
