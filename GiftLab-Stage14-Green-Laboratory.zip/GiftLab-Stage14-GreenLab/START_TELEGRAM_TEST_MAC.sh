#!/usr/bin/env bash
# Only for an independently created TEST BOT in Telegram TEST ENVIRONMENT.
# DO NOT use your real production bot token in this script.
set -euo pipefail
cd "$(dirname "$0")"
echo 'Test Telegram Bot API token (hidden):'
IFS= read -rs BOT_TOKEN
printf '\n'
export BOT_TOKEN
export ENABLE_XTR_SUPPORT=1
export XTR_TEST_MODE=1
export PORT=3024
node server.js
