'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const pub=path.join(__dirname,'..','public');
test('Stage 12 is a real app UI with case buttons, not a replacement screenshot',()=>{
 const js=fs.readFileSync(path.join(pub,'app.js'),'utf8');
 const css=fs.readFileSync(path.join(pub,'style.css'),'utf8');
 assert.match(js,/const caseTile=c=>/);
 assert.match(js,/data-act="case"/);
 assert.match(js,/gl12-open-btn/);
 assert.match(js,/gl12-case-grid/);
 assert.match(js,/STAGE (?:13\.1|14\.0)/);
 assert.match(css,/@media\(min-width:1150px\)/);
 for(const name of ['signal','neon','winter','black','durov','collectors','whale']) assert.ok(fs.statSync(path.join(pub,'assets','cases',name+'.webp')).size>1200,name);
});
