'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
const {MarketObserver,discountFloor}=require('../market');

async function setup(t){
 const socket=net.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 const home=fs.mkdtempSync(path.join(os.tmpdir(),'giftlab9-'));
 const child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),BOT_TOKEN:'',GIFT_LAB_DATA_DIR:home,NODE_ENV:'development'},stdio:'ignore'});
 t.after(()=>{child.kill();fs.rmSync(home,{recursive:true,force:true})});
 const base=`http://127.0.0.1:${port}`;
 for(let i=0;i<80;i++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await new Promise(r=>setTimeout(r,60));}
 async function call(path,token,body){const res=await fetch(base+path,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:res.status,data:await res.json()};}
 const auth=(await call('/api/auth',null,{demoName:'TestNine'})).data;
 return {base,call,token:auth.token};
}

test('Stage 9: sandbox Stars credits once; duplicate ID replays snapshot; changes rejected',async t=>{
 const {call,token}=await setup(t);
 const rid='1e155a23-9cec-4c9e-a0cc-a83ab471d4ab';
 const one=await call('/api/deposit/sandbox-credit',token,{requestId:rid,amount:730});
 assert.equal(one.status,200);assert.equal(one.data.user.balance,12715);assert.equal(one.data.entry.realPayment,false);
 const two=await call('/api/deposit/sandbox-credit',token,{requestId:rid,amount:730});
 assert.equal(two.status,200);assert.equal(two.data.replayed,true);assert.equal(two.data.user.balance,12715);
 assert.equal((await call('/api/deposit/sandbox-credit',token,{requestId:rid,amount:740})).status,409);
 assert.equal((await call('/api/deposit/sandbox-credit',token,{requestId:'2b143c25-9cec-4c9e-a0cc-a83ab471d4ab',amount:-2})).status,400);
 const history=await call('/api/deposit/history',token);
 assert.equal(history.status,200);assert.equal(history.data.entries.length,1);assert.equal(history.data.realPaymentsEnabled,false);
});

test('Stage 9: honest TON quote and protected NFT requests',async t=>{
 const {call,token}=await setup(t);
 const q=await call('/api/deposit/quote?method=ton&amount=2.5',token);
 assert.equal(q.status,200);assert.equal(q.data.bonusTon,'0.125');assert.equal(q.data.totalTon,'2.625');assert.equal(q.data.realPaymentsEnabled,false);
 const bad=await call('/api/deposit/quote?method=stars&amount=1e3',token);assert.equal(bad.status,400);
 const nft=await call('/api/deposit/quote?method=nft&collection=Toy%20Bear',token);assert.equal(nft.status,400,'unknown price means no NFT quote');
 const available=await call('/api/deposit/collections',token);assert.equal(available.status,200);assert.ok(available.data.items.every(x=>Number(x.floorTon)>0));
 const request=await call('/api/deposit/nft-sandbox-request',token,{collection:'Made Up',requestId:'11e55a23-9cec-4c9e-a0cc-a83ab471d4ab'});assert.equal(request.status,400);
 const catalog=await call('/api/cases',token);assert.equal(catalog.status,200);
 assert.ok(catalog.data[0].items.some(x=>x.kind==='collectible-preview'),'demo NFT previews remain playable while real deposits require observed market prices');
});

test('Stage 9: market floor uses collection name, unavailable/stale not made up; decimal discount',()=>{
 const now=Date.parse('2026-11-09T03:00:00Z');
 const m=new MarketObserver({clock:()=>now,fetchFn:async()=>{throw Error('offline')}});
 m.prices=[{slug:'toybear',name:'Toy Bear',floorTon:'8.7654321',observationDate:'2026-11-08',source:'Fixture daily floor',sourceUrl:'https://example.org'}];
 assert.equal(m.giftFloor('Toy Bear').floorTon,'8.7654321');
 assert.equal(m.giftFloor('Plush Pepe').available,false);
 assert.equal(discountFloor('10',7),'9.3');assert.equal(discountFloor('8.7654321',7),'8.15185185');
 m.prices[0].observationDate='2026-11-01';
 assert.equal(m.giftFloor('Toy Bear').available,false);assert.equal(m.giftFloor('Toy Bear').floorTon,null);
});
