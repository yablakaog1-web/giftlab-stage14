'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { spawn } = require('node:child_process');
const os = require('node:os'), fs = require('node:fs'), path = require('node:path'), net = require('node:net');

async function startServer(t) {
  const s = net.createServer(); await new Promise(r => s.listen(0, '127.0.0.1', r));
  const port = s.address().port; await new Promise(r => s.close(r));
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'gift-lab-s1-'));
  const child = spawn(process.execPath, ['server.js'], { cwd: path.join(__dirname, '..'), stdio: 'ignore',
    env: { ...process.env, PORT: String(port), GIFT_LAB_DATA_DIR: temp, NODE_ENV: 'development', BOT_TOKEN: '' } });
  t.after(() => { child.kill(); fs.rmSync(temp, { recursive: true, force: true }); });
  const base = `http://127.0.0.1:${port}`;
  for (let i = 0; i < 80; i++) { try { if ((await fetch(base + '/api/health')).ok) break; } catch {} await new Promise(r => setTimeout(r, 100)); }
  const call = async (route, token, body) => {
    const r = await fetch(base + route, { method: body !== undefined ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
      ...(body !== undefined ? { body: JSON.stringify(body) } : {}) });
    return { status: r.status, json: await r.json() };
  };
  return { base, call };
}

test('кейсы: цены, вероятности = 100%, математическое ожидание, нет несоразмерных призов', async t => {
  const { call } = await startServer(t);
  const { json: { token } } = await call('/api/auth', null, { demoName: 'Игрок1' });
  const { json: cases } = await call('/api/cases', token);
  assert.deepEqual(cases.slice(0,16).map(c => c.price), [25,50,100,150,250,350,500,750,1000,1500,2000,2500,3000,3500,4000,5000]);
  assert.ok(cases.every(c => Math.abs(c.ev - c.items.reduce((sum,i)=>sum+i.value*i.p/100,0)) < .011));
  for (const c of cases.slice(0,16)) {
    assert.ok(Math.abs(c.items.reduce((s, i) => s + i.p, 0)-100)<.00001, c.name);
    assert.ok(c.items.every(i=>i.p>0 && (i.image || i.kind==='stars')));
    assert.ok(Math.max(...c.items.map(i => i.value)) <= c.price * (c.price===25?12:6), 'контролируемый редкий приз максимум 12× для стартового кейса');
  }
});

test('демо-звёзды: +500 раз в час, повтор отклоняется; статистика растёт', async t => {
  const { call } = await startServer(t);
  const { json: a } = await call('/api/auth', null, { demoName: 'Игрок1' });
  assert.equal(a.user.balance, 12000);
  for (const key of ['cases','items','upgrades','pvp','spent','sales','earned','gameWins']) assert.equal(a.user.stats[key],0,key);
  const first = await call('/api/demo-stars', a.token, {});
  assert.equal(first.status, 200); assert.equal(first.json.user.balance, 17000);
  const second = await call('/api/demo-stars', a.token, {});
  assert.equal(second.status, 429); assert.ok(second.json.wait > 0);
  const opened = await call('/api/cases/open', a.token, { caseId: 'lucky' });
  assert.equal(opened.json.user.balance, 16950+(opened.json.item.kind==='stars'?opened.json.item.value:0));
  assert.equal(opened.json.user.stats.cases, 1); assert.equal(opened.json.user.stats.spent, 50);
  assert.equal(opened.json.user.history[0].delta, -50);
  assert.equal((await call('/api/cases/open', a.token, { caseId: 'нет' })).status, 400);
});

test('нельзя открыть кейс без денег и войти без токена', async t => {
  const { call } = await startServer(t);
  const { json: a } = await call('/api/auth', null, { demoName: 'Игрок1' });
  const broke = await call('/api/cases/open', a.token, { caseId: 'ultimate', count: 3 }); // 15 000 > 12 000
  assert.equal(broke.status, 400); assert.match(broke.json.error, /демо-звёзд/);
  assert.equal((await call('/api/cases')).status, 401);
});

test('повторная отправка открытия с тем же requestId не списывает звёзды дважды', async t => {
  const { call } = await startServer(t);
  const { json: a } = await call('/api/auth', null, { demoName: 'Игрок1' });
  const body = { caseId: 'starter', requestId: 'req-12345678' };
  const one = await call('/api/cases/open', a.token, body);
  const two = await call('/api/cases/open', a.token, body);
  assert.equal(one.json.item.id, two.json.item.id);assert.equal(two.json.replayed,true);
  const me = (await call('/api/me', a.token)).json.user;
  assert.equal(me.balance, 11975+(one.json.item.kind==='stars'?one.json.item.value:0)); assert.equal(me.stats.cases, 1); assert.equal(me.inventory.length, one.json.item.kind==='stars'?0:1);
  const three = await call('/api/cases/open', a.token, { caseId: 'starter', requestId: 'req-87654321' });
  assert.equal(three.json.user.balance,me.balance-25+(three.json.item.kind==='stars'?three.json.item.value:0));
});
