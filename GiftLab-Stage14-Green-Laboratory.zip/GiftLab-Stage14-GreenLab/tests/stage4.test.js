'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
async function setup(t){
 const ss=net.createServer();await new Promise(ok=>ss.listen(0,'127.0.0.1',ok));const port=ss.address().port;await new Promise(ok=>ss.close(ok));
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'gl-stage4-'));
 const child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),GIFT_LAB_DATA_DIR:tmp,NODE_ENV:'development',BOT_TOKEN:'',ROCKET_WAIT_MS:'250'},stdio:'ignore'});
 t.after(()=>{child.kill();fs.rmSync(tmp,{recursive:true,force:true})});const base='http://127.0.0.1:'+port;
 for(let i=0;i<50;i++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await new Promise(ok=>setTimeout(ok,80));}
 async function call(url,token,body){const r=await fetch(base+url,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:r.status,data:await r.json()}}
 const alice=(await call('/api/auth',null,{demoName:'Яблочко'})).data;const bob=(await call('/api/auth',null,{demoName:'Витёк'})).data;return {call,alice,bob,tmp};
}
test('продажа подарка меняет баланс и инвентарь, повторно продать нельзя',async t=>{
 const {call,alice}=await setup(t);let gift;
 for(let k=0;k<60;k++){const r=await call('/api/cases/open',alice.token,{caseId:'starter'});assert.equal(r.status,200);if(r.data.item.instanceId){gift=r.data.item;break;}}
 assert.ok(gift,'regular gift awarded in case opening');
 const before=(await call('/api/me',alice.token)).data.user;
 const result=await call('/api/inventory/sell',alice.token,{instanceId:gift.instanceId});
 assert.equal(result.status,200);assert.equal(result.data.payout,gift.value);
 assert.equal(result.data.user.balance,before.balance+result.data.payout);
 assert.equal(result.data.user.inventory.length,before.inventory.length-1);
 assert.equal((await call('/api/inventory/sell',alice.token,{instanceId:gift.instanceId})).status,400);
 const ranks=await call('/api/leaders?period=week&metric=sales',alice.token);
 assert.equal(ranks.data.mine.value,1);assert.ok(ranks.data.mine.rank>=1);
 const today=await call('/api/leaders?period=today&metric=cases',alice.token);
 assert.ok(today.data.mine.value>=1);
 const earnings=await call('/api/leaders?period=all&metric=earned',alice.token);
 assert.ok(earnings.data.mine.value>=result.data.payout); // case stars also count as earned
});
test('PvP: настоящие выпадения двух участников, общий виртуальный инвентарь победителя',async t=>{
 const {call,alice,bob,tmp}=await setup(t);
 const create=await call('/api/rooms/create',alice.token,{caseId:'starter',rounds:3});
 assert.equal(create.status,200);assert.equal(create.data.room.stake,75);
 const id=create.data.room.id;
 assert.equal((await call(`/api/rooms/${id}/join`,alice.token,{})).status,400);
 const joined=await call(`/api/rooms/${id}/join`,bob.token,{});
 assert.equal(joined.status,200);const r=joined.data.room;
 assert.equal(r.status,'finished');assert.equal(r.rolls.creator.length,3);assert.equal(r.rolls.joiner.length,3);
 assert.equal(r.totals.creator,r.rolls.creator.reduce((s,i)=>s+i.value,0));
 assert.equal(r.totals.joiner,r.rolls.joiner.reduce((s,i)=>s+i.value,0));
 assert.equal(r.awardItems,[...r.rolls.creator,...r.rolls.joiner].filter(x=>x.kind!=='stars').length);
 const a=(await call('/api/me',alice.token)).data.user,b=(await call('/api/me',bob.token)).data.user;
 assert.equal(a.balance+b.balance,24000-150+[...r.rolls.creator,...r.rolls.joiner].filter(x=>x.kind==='stars').reduce((sum,x)=>sum+x.value,0));
 assert.deepEqual([a.inventory.length,b.inventory.length].sort((x,y)=>x-y),[0,r.awardItems]);
 assert.equal(a.stats.pvp+b.stats.pvp,1);
 assert.equal((await call(`/api/rooms/${id}/join`,bob.token,{})).status,400);
 assert.equal(JSON.parse(fs.readFileSync(path.join(tmp,'game.json'),'utf8')).rooms[id].status,'finished');
});
test('Mines: секретные мины, серверная проверка клеток, получение звёзд',async t=>{
 const {call,alice}=await setup(t);let won=false;
 for(let attempt=0;attempt<9&&!won;attempt++){
  const start=await call('/api/mines/start',alice.token,{stake:25,count:1});
  assert.equal(start.status,200);assert.equal(start.data.round.mines,null);
  let open=await call('/api/mines/reveal',alice.token,{cell:attempt%25});
  assert.equal(open.status,200);
  if(open.data.round.status==='active'){
   assert.equal(open.data.round.mines,null);
   assert.equal(open.data.round.revealed.length,1);
   assert.equal((await call('/api/mines/reveal',alice.token,{cell:attempt%25})).status,400);
   const cash=await call('/api/mines/cashout',alice.token,{});
   assert.equal(cash.status,200);assert.ok(cash.data.round.payout>=24);
   assert.equal(cash.data.round.status,'cashed');won=true;
  }else assert.equal(open.data.round.status,'lost');
 }
 assert.ok(won,'Found at least one safe cell in 9 rounds');
});
test('Rocket: 10-second waiting mechanic (shortened in test), shared round, no double cashout',async t=>{
 const {call,alice,bob}=await setup(t);
 const x=await call('/api/rocket/state',alice.token);
 const y=await call('/api/rocket/state',bob.token);
 assert.equal(x.data.round.id,y.data.round.id);
 assert.equal(x.data.round.status,'waiting');
 assert.equal(x.data.round.crashAt,null);
 const stake=await call('/api/rocket/start',alice.token,{stake:25});
 assert.equal(stake.status,200);
 assert.equal(stake.data.round.hasBet,true);
 assert.equal((await call('/api/rocket/start',alice.token,{stake:25})).status,400);
 assert.equal((await call('/api/rocket/cashout',alice.token,{})).status,400);
 await new Promise(ok=>setTimeout(ok,300));
 const active=await call('/api/rocket/state',bob.token);
 assert.equal(active.data.round.status,'active');
 assert.equal(active.data.round.hasBet,false);
 assert.equal((await call('/api/rocket/start',bob.token,{stake:25})).status,400);
 const cash=await call('/api/rocket/cashout',alice.token,{});
 assert.equal(cash.status,200);
 assert.equal(cash.data.round.cashed,true);
 assert.ok(cash.data.round.payout>=25);
 assert.equal((await call('/api/rocket/cashout',alice.token,{})).status,400);
});
