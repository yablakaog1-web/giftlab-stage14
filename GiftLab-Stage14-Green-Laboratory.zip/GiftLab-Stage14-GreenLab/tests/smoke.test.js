'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const os=require('node:os');
const fs=require('node:fs');
const path=require('node:path');
const net=require('node:net');

async function freePort(){
  const s=net.createServer();
  await new Promise(r=>s.listen(0,'127.0.0.1',r));
  const port=s.address().port;
  await new Promise(r=>s.close(r));
  return port;
}

test('case → upgrade → real two-player duel → persistence',async t=>{
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'gift-lab-test-'));
  const port=await freePort();
  const base=`http://127.0.0.1:${port}`;
  const child=spawn(process.execPath,['server.js'],{
    cwd:path.join(__dirname,'..'),
    env:{...process.env,PORT:String(port),GIFT_LAB_DATA_DIR:temp,NODE_ENV:'development',BOT_TOKEN:''},
    stdio:'ignore'
  });
  t.after(()=>{child.kill();fs.rmSync(temp,{recursive:true,force:true});});
  let online=false;
  for(let i=0;i<80;i++){
    if(child.exitCode!==null)throw Error('Child server exited');
    try{const r=await fetch(base+'/api/health');if(r.ok){online=true;break;}}catch{}
    await new Promise(r=>setTimeout(r,100));
  }
  assert.equal(online,true,'Server started');
  async function req(route,token,body){
    const r=await fetch(base+route,{method:body!==undefined?'POST':'GET',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body!==undefined?{body:JSON.stringify(body)}:{})});
    const out=await r.json();assert.equal(r.ok,true,JSON.stringify(out));return out;
  }
  const {items,cases}=await req('/api/catalog');
  assert.ok(cases.length>=22);
  assert.ok(items.length>=40);
  const alice=await req('/api/auth',null,{demoName:'Alice'});
  const bob=await req('/api/auth',null,{demoName:'Bob'});
  assert.equal(alice.user.balance,12000);
  let owned=null;
  for(let n=0;n<50;n++){
    const opening=await req('/api/cases/open',alice.token,{caseId:'starter'});
    if(opening.item.instanceId){owned=opening.item;break;}
  }
  assert.ok(owned,'a regular item must be obtainable from the case');
  const bigger=items.find(i=>i.kind==='regular'&&i.value>owned.value);
  assert.ok(bigger);
  const upgraded=await req('/api/upgrade',alice.token,{instanceId:owned.instanceId,targetId:bigger.id});
  assert.equal(typeof upgraded.success,'boolean');
  const room=await req('/api/rooms/create',alice.token,{stake:100});
  const list=await req('/api/rooms',bob.token);
  assert.ok(list.rooms.some(r=>r.id===room.room.id));
  const joined=await req('/api/rooms/'+room.room.id+'/join',bob.token,{});
  assert.equal(joined.room.status,'finished');
  assert.ok([alice.user.id,bob.user.id].includes(joined.room.winnerId));
  const A=(await req('/api/me',alice.token)).user;
  const B=(await req('/api/me',bob.token)).user;
  assert.ok(A.balance>=0&&B.balance>=0); // stars prizes may credit balance directly
  const stored=JSON.parse(fs.readFileSync(path.join(temp,'game.json')));
  assert.equal(stored.rooms[room.room.id].status,'finished');
  const denied=await fetch(base+'/api/me');
  assert.equal(denied.status,401);
});

test('Telegram auth: valid HMAC works; forged payload and demo login are rejected',async t=>{
  const crypto=require('node:crypto');
  const temp=fs.mkdtempSync(path.join(os.tmpdir(),'gift-lab-auth-'));
  const port=await freePort();
  const token='123456789:THIS_IS_NOT_A_REAL_BOT_TOKEN_FOR_TESTS';
  const base=`http://127.0.0.1:${port}`;
  const child=spawn(process.execPath,['server.js'],{
    cwd:path.join(__dirname,'..'),
    env:{...process.env,PORT:String(port),GIFT_LAB_DATA_DIR:temp,NODE_ENV:'production',BOT_TOKEN:token},
    stdio:'ignore'
  });
  t.after(()=>{child.kill();fs.rmSync(temp,{recursive:true,force:true});});
  let ready=false;
  for(let i=0;i<80;i++){
    try {const r=await fetch(base+'/api/health');if(r.ok){ready=true;break;}}catch{}
    await new Promise(r=>setTimeout(r,100));
  }
  assert.ok(ready);
  const user=JSON.stringify({id:345612398,first_name:'Витёк'});
  const params=new URLSearchParams({auth_date:String(Math.floor(Date.now()/1000)),user});
  const text=[...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>k+'='+v).join('\n');
  const secret=crypto.createHmac('sha256','WebAppData').update(token).digest();
  const hash=crypto.createHmac('sha256',secret).update(text).digest('hex');
  params.set('hash',hash);
  async function logIn(value){
    return fetch(base+'/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(value)});
  }
  const legitimate=await logIn({initData:params.toString()});
  assert.equal(legitimate.status,200);
  const payload=await legitimate.json();
  assert.equal(payload.user.id,'tg:345612398');
  params.set('user',JSON.stringify({id:999,first_name:'Подмена'}));
  assert.equal((await logIn({initData:params.toString()})).status,401);
  assert.equal((await logIn({demoName:'Яблочко'})).status,401);
});
