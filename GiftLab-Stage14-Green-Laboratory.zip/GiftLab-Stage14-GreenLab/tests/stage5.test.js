'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
async function setup(t){
 const sock=net.createServer();await new Promise(ok=>sock.listen(0,'127.0.0.1',ok));const port=sock.address().port;await new Promise(ok=>sock.close(ok));
 const data=fs.mkdtempSync(path.join(os.tmpdir(),'gift-stage5-'));
 const child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),GIFT_LAB_DATA_DIR:data,NODE_ENV:'development',BOT_TOKEN:'',ROCKET_WAIT_MS:'250'},stdio:'ignore'});
 t.after(()=>{child.kill();fs.rmSync(data,{recursive:true,force:true})});
 const base='http://127.0.0.1:'+port;
 for(let n=0;n<40;n++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await new Promise(ok=>setTimeout(ok,60));}
 async function call(url,token,body){const r=await fetch(base+url,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:r.status,data:await r.json()};}
 const alice=(await call('/api/auth',null,{demoName:'Яблочко'})).data;const bob=(await call('/api/auth',null,{demoName:'Витёк'})).data;return {call,alice,bob};
}
test('Sell all is atomic, 0% commission, repeat returns 400, leaderboard counts every item',async t=>{
 const {call,alice}=await setup(t);
 let before;
 for(let k=0;k<60;k++){
   const opened=await call('/api/cases/open',alice.token,{caseId:'starter'});
   assert.equal(opened.status,200);
   if(opened.data.user.inventory.length>=2){before=opened.data.user;break;}
 }
 assert.ok(before);
 const count=before.inventory.length,total=before.inventory.reduce((sum,x)=>sum+x.value,0);
 const sell=await call('/api/inventory/sell-all',alice.token,{});
 assert.equal(sell.status,200);assert.equal(sell.data.count,count);assert.equal(sell.data.payout,total);
 assert.equal(sell.data.user.balance,before.balance+total);assert.equal(sell.data.user.inventory.length,0);
 assert.equal((await call('/api/inventory/sell-all',alice.token,{})).status,400);
 const ranks=(await call('/api/leaders?period=week&metric=sales',alice.token)).data;
 assert.equal(ranks.mine.value,count);
});
test('Stage 6: original 15-star Bear image, 16 proportional cases and distinct NFT previews',async t=>{
 const {call,alice}=await setup(t);
 const cases=(await call('/api/cases',alice.token)).data;
 const catalog=(await call('/api/catalog',alice.token)).data;
 assert.ok(cases.length>=22);
 assert.equal(cases.find(c=>c.id==='ultimate').price,5000);
 const bear=catalog.items.find(i=>i.id==='regular-bear');
 const toyBearNft=catalog.items.find(i=>i.id==='nft-toybear');
 assert.equal(bear.value,15);
 assert.equal(bear.telegramGiftId,'5170233102089322756');
 assert.equal(bear.kind,'regular');
 assert.equal(bear.image,'https://giftclub.app/assets/teddy-P7L5OrDb.webp');
 assert.ok(toyBearNft && toyBearNft.priceType==='demo-catalogue','collectibles are simulated only, not observed floors');
 for(const c of cases.slice(0,16)){
  assert.ok(Math.abs(c.items.reduce((s,i)=>s+i.p,0)-100)<.00001);
  assert.ok(c.items.every(i=>i.value<=(c.price===25?12:6)*c.price));
 }
 assert.ok(cases.find(c=>c.price===100).items.some(i=>i.kind==='stars'));
 const it=(await call('/api/cases/open',alice.token,{caseId:'starter'})).data.item;
 assert.ok(['regular','stars','collectible-preview'].includes(it.kind));
 assert.ok(['fixed','demo','demo-catalogue'].includes(it.priceType));
});
test('Custom Rocket and Mines demo stakes accept integer input and reject invalid amounts',async t=>{
 const {call,alice,bob}=await setup(t);
 const rocket=await call('/api/rocket/start',alice.token,{stake:173});
 assert.equal(rocket.status,200);
 assert.equal(rocket.data.round.stake,173);
 assert.equal((await call('/api/rocket/start',bob.token,{stake:0})).status,400);
 assert.equal((await call('/api/rocket/start',bob.token,{stake:100001})).status,400);
 assert.equal((await call('/api/rocket/start',bob.token,{stake:1.5})).status,400);
 const mines=await call('/api/mines/start',bob.token,{stake:117,count:2});
 assert.equal(mines.status,200);
 assert.equal(mines.data.round.stake,117);
});
