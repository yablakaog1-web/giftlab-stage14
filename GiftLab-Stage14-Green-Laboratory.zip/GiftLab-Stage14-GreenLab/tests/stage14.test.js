'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const {PRODUCT,startOrder,precheckout,settle}=require('../xtr-support');
const dir=path.resolve(__dirname,'..');
test('XTR official invoice product is a fixed-price supporter badge, NOT gameplay credits',()=>{
 assert.equal(PRODUCT.currency,'XTR');assert.equal(PRODUCT.price,25);
 assert.match(PRODUCT.description,/Не является игровой валютой/);
});
test('Support invoice is bound to Telegram ID and amount, rejects tampering and expiration',()=>{
 const state={supportOrders:{},supportCharges:{},users:{'tg:123':{id:'tg:123',balance:500,labSupporter:false}}};
 const order=startOrder(state,state.users['tg:123'],10000000);
 assert.equal(startOrder(state,state.users['tg:123'],10000001).id,order.id);
 const q={invoice_payload:'support:'+order.id,currency:'XTR',total_amount:25,from:{id:123}};
 assert.equal(precheckout(state,q,10000001).ok,true);
 assert.equal(precheckout(state,{...q,from:{id:456}},10000001).ok,false);
 assert.equal(precheckout(state,{...q,total_amount:250},10000001).ok,false);
 assert.equal(precheckout(state,q,10000000+20*60*1000).ok,false);
});
test('Stars successful_payment delivers badge only once and never credits spendable demo stars',()=>{
 const state={supportOrders:{},supportCharges:{},users:{'tg:123':{id:'tg:123',balance:12000,labSupporter:false}}};
 const order=startOrder(state,state.users['tg:123'],Date.now());
 const msg={from:{id:123},successful_payment:{invoice_payload:'support:'+order.id,currency:'XTR',total_amount:25,telegram_payment_charge_id:'charge-123'}};
 assert.equal(settle(state,{...msg,from:{id:999}}).accepted,false);
 assert.equal(state.users['tg:123'].balance,12000);
 assert.equal(settle(state,msg).accepted,true);
 assert.equal(state.users['tg:123'].labSupporter,true);
 assert.equal(state.users['tg:123'].balance,12000);
 assert.equal(settle(state,msg).duplicate,true);
 assert.equal(Object.keys(state.supportCharges).length,1);
});
test('Green Laboratory is served using real local SVG and CSS, not an image screenshot',()=>{
 const js=fs.readFileSync(path.join(dir,'public/app.js'),'utf8');
 const css=fs.readFileSync(path.join(dir,'public/style.css'),'utf8');
 const html=fs.readFileSync(path.join(dir,'public/index.html'),'utf8');
 assert.match(js,/RESEARCH FACILITY/);assert.match(js,/Смешивай/);
 assert.match(css,/GIFT LAB 14\.0/);assert.match(css,/--lab-green:/);
 assert.match(html,/style\.css\?v=14\.0/);
 for(const f of ['public/assets/lab/logo.svg','public/assets/lab/hero.svg'])assert.match(fs.readFileSync(path.join(dir,f),'utf8'),/<svg/);
});
