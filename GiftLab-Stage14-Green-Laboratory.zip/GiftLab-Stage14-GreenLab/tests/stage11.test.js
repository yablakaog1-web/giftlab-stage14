'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
async function app(t){
 const sock=net.createServer();await new Promise(r=>sock.listen(0,'127.0.0.1',r));const port=sock.address().port;await new Promise(r=>sock.close(r));
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'gl-stage11-'));
 const child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),GIFT_LAB_DATA_DIR:dir,NODE_ENV:'development',BOT_TOKEN:'',DEMO_STAR_USD:''},stdio:'ignore'});
 t.after(()=>{child.kill();fs.rmSync(dir,{recursive:true,force:true})});
 const base=`http://127.0.0.1:${port}`;
 for(let i=0;i<80;i++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await new Promise(r=>setTimeout(r,40));}
 async function call(url,token){const r=await fetch(base+url,{headers:token?{Authorization:'Bearer '+token}:{}});return{status:r.status,data:await r.json()};}
 const auth=await fetch(base+'/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({demoName:'Stage11'})}).then(r=>r.json());
 return{call,token:auth.token,base};
}
test('Stage 11 restores complete 24 NFT preview catalog while keeping fake floor separate',async t=>{
 const{call,token}=await app(t),d=(await call('/api/catalog',token)).data,cs=(await call('/api/cases',token)).data;
 const collectibles=d.items.filter(x=>x.kind==='collectible-preview');
 assert.equal(collectibles.length,42);
 assert.ok(collectibles.every(i=>i.priceType==='demo-catalogue'));
 assert.ok(cs.every(c=>c.items.reduce((s,i)=>s+i.p,0)>99.999));
 assert.ok(cs.slice(0,16).filter(c=>c.price>=500).every(c=>c.items.filter(i=>i.kind==='collectible-preview').length>=8));
 assert.ok(cs.some(c=>c.items.filter(i=>i.kind==='stars').length>=5));
 const nft=(await call('/api/deposit/collections',token)).data;
 assert.ok(nft.items.every(i=>Number(i.floorTon)>0 && i.observedAt));
});
test('Stage 11 HTML showcases in-case gifts, rocket orientation is not sideways, and version bump',async t=>{
 const{base}=await app(t);
 const html=await fetch(base+'/app.js').then(r=>r.text());
 const css=await fetch(base+'/style.css').then(r=>r.text());
 assert.match(html,/caseShowcase/);
 assert.match(html,/showcase-gift/);
 assert.match(html,/rotate\(29deg\)/);
 assert.doesNotMatch(html,/rotate\(54deg\)/);
 assert.match(css,/@keyframes stage11Hover/);
 assert.match(html,/STAGE (?:11|12|13|14)\.(?:0|1)/);
});
