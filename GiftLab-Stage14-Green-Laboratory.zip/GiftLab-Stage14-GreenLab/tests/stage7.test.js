'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
async function game(t){
 const sock=net.createServer();await new Promise(r=>sock.listen(0,'127.0.0.1',r));const port=sock.address().port;await new Promise(r=>sock.close(r));
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'giftlab7-'));
 const child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),GIFT_LAB_DATA_DIR:tmp,BOT_TOKEN:'',NODE_ENV:'development',ROCKET_WAIT_MS:'250'},stdio:'ignore'});
 t.after(()=>{child.kill();fs.rmSync(tmp,{recursive:true,force:true})});
 const base='http://127.0.0.1:'+port;
 for(let i=0;i<70;i++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await new Promise(r=>setTimeout(r,60));}
 async function call(uri,token,body){const res=await fetch(base+uri,{method:body===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});return {status:res.status,data:await res.json()}}
 const user=(await call('/api/auth',null,{demoName:'TestSeven'})).data;return{call,token:user.token};
}
test('Stage 7 curated cases, real server odds, 8+ collectibles, demo stars',async t=>{
 const{call,token}=await game(t);const cases=(await call('/api/cases',token)).data;
 assert.ok(cases.length>=22);
 assert.deepEqual(cases.filter(x=>['starter','nova','cosmos'].includes(x.id)).map(x=>x.price),[25,1000,2500]);
 for(const c of cases.slice(0,16)){assert.ok(Math.abs(c.items.reduce((a,i)=>a+i.p,0)-100)<.00001);assert.ok(c.ev/c.price>0.8 && c.ev/c.price<0.96);if(c.price>=500){assert.ok(c.items.filter(i=>i.kind==='stars').length>=5,c.name);assert.ok(c.items.filter(i=>i.kind==='collectible-preview').length>=8,'premium demo cases contain varied collectibles');}}
 const first=cases[0];assert.ok(first.items.some(i=>i.kind==='stars'));
});
test('Stage 7 batch case opening 1-3, unique instances, same request id returns same result',async t=>{
 const{call,token}=await game(t);
 const rid='batch-test-123456';const a=await call('/api/cases/open',token,{caseId:'starter',count:3,requestId:rid});assert.equal(a.status,200);assert.equal(a.data.items.length,3);assert.equal(a.data.user.stats.cases,3);assert.equal(a.data.user.balance,12000-75+a.data.items.filter(i=>i.kind==='stars').reduce((s,i)=>s+i.value,0));
 assert.equal(new Set(a.data.items.filter(i=>i.instanceId).map(i=>i.instanceId)).size,a.data.items.filter(i=>i.instanceId).length);
 const dup=await call('/api/cases/open',token,{caseId:'starter',count:3,requestId:rid});assert.equal(dup.status,200);assert.deepEqual(dup.data.items.map(i=>i.id),a.data.items.map(i=>i.id));assert.equal(dup.data.replayed,true);
 assert.equal((await call('/api/cases/open',token,{caseId:'starter',count:4})).status,400);
 assert.equal((await call('/api/cases/open',token,{caseId:'ultimate',count:3})).status,400);
});
test('Stage 7 three-item & star-only upgrades validated server-side',async t=>{
 const{call,token}=await game(t);
 const all=[];
 for(let n=0;n<60&&all.length<3;n++){
   const opened=(await call('/api/cases/open',token,{caseId:'starter'})).data.item;
   if(opened.instanceId&&opened.value<=25)all.push(opened);
 }
 assert.equal(all.length,3);
 const ids=all.map(x=>x.instanceId);
 const invalid=await call('/api/upgrade',token,{instanceIds:[...ids,ids[0]],stars:0,targetId:'regular-gem'});
 assert.equal(invalid.status,400);
 const withItems=await call('/api/upgrade',token,{instanceIds:ids,stars:5,targetId:'regular-gem'});
 assert.equal(withItems.status,200);assert.equal(withItems.data.itemsSpent,3);assert.equal(withItems.data.starsSpent,5);
 assert.equal(withItems.data.sourceValue,all.reduce((sum,x)=>sum+x.value,5));
 const repeated=await call('/api/upgrade',token,{instanceIds:ids,stars:0,targetId:'regular-gem'});assert.equal(repeated.status,400);
 const stars=await call('/api/upgrade',token,{instanceIds:[],stars:20,targetId:'regular-gem'});
 assert.equal(stars.status,200);assert.equal(stars.data.sourceValue,20);assert.ok(stars.data.chance>0 && stars.data.chance<.9);
 const zero=await call('/api/upgrade',token,{instanceIds:[],stars:0,targetId:'regular-gem'});assert.equal(zero.status,400);
});
test('Stage 7 star rewards credit balance directly, not inventory',async t=>{
 const{call,token}=await game(t);
 let verified=false;for(let i=0;i<42;i++){
  const before=(await call('/api/me',token)).data.user;
  const opening=await call('/api/cases/open',token,{caseId:'gift'});assert.equal(opening.status,200);
  const drop=opening.data.item;
  if(drop.kind==='stars'){
   assert.equal(opening.data.user.balance,before.balance-100+drop.value);
   assert.equal(opening.data.user.inventory.length,before.inventory.length);verified=true;break;
  }
 }
 assert.ok(verified,'at least one credited star drop in 42 openings');
});
