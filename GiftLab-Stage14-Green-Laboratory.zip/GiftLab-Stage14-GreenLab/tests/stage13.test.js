'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const {spawn}=require('node:child_process');
const {MarketObserver,parseDaily}=require('../market');
async function testApp(t){
 const socket=net.createServer();await new Promise(r=>socket.listen(0,'127.0.0.1',r));const port=socket.address().port;await new Promise(r=>socket.close(r));
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'gl13-'));
 const child=spawn(process.execPath,['server.js'],{cwd:path.join(__dirname,'..'),env:{...process.env,PORT:String(port),GIFT_LAB_DATA_DIR:dir,NODE_ENV:'development',BOT_TOKEN:'',DEMO_STAR_USD:''},stdio:'ignore'});
 t.after(()=>{child.kill();fs.rmSync(dir,{recursive:true,force:true})});
 const base='http://127.0.0.1:'+port;
 for(let k=0;k<80;k++){try{if((await fetch(base+'/api/health')).ok)break}catch{}await new Promise(r=>setTimeout(r,50))}
 async function call(route,token){const r=await fetch(base+route,{headers:token?{Authorization:'Bearer '+token}:{}});return {status:r.status,data:route.includes('/app.js')?await r.text():await r.json()}}
 const a=await fetch(base+'/api/auth',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({demoName:'Stage13QA'})}).then(r=>r.json());
 return {call,token:a.token};
}
test('Stage 13: Snoop, winter, Pepe curated cases and exactly three demo rewards',async t=>{
 const {call,token}=await testApp(t),resp=await call('/api/cases',token);assert.equal(resp.status,200);
 const cases=resp.data;assert.equal(cases.length,22);
 const by=id=>cases.find(c=>c.id===id);
 assert.deepEqual(by('micro').items.map(i=>i.n),['1 демо-звёзд','3 демо-звёзд','Snoop Dogg']);
 assert.equal(by('micro').items.find(i=>i.n==='Snoop Dogg').value,1000);
 assert.equal(by('snoop').items.length,5);assert.ok(by('snoop').items.every(i=>['Snoop Dogg','Snoop Cigar','Low Rider','Swag Bag','Westside Sign'].includes(i.n)));
 assert.ok(by('newyear').items.length>=8 && by('newyear').items.some(i=>i.n==='Santa Hat'));
 assert.ok(by('pepe').items.some(i=>i.n==='Plush Pepe'));
 for(const c of cases){assert.ok(Math.abs(c.items.reduce((n,i)=>n+i.p,0)-100)<.001,c.id)}
});
test('Stage 13: case details no longer render percentages; new catalog uses demovalues, not fake market',async t=>{
 const {call,token}=await testApp(t);
 const cat=(await call('/api/catalog',token)).data.items;
 assert.equal(cat.filter(x=>x.kind==='collectible-preview').length,42);
 assert.equal(cat.find(x=>x.id==='nft-plushpepe').priceType,'demo-catalogue');
 const app=(await call('/app.js')).data;assert.doesNotMatch(app,/class="fairness card space"/);assert.match(app,/gl13-collage/);
});
test('Stage 13: singular gift labels match observed plural market floor without guessing',()=>{
 const now=Date.parse('2026-11-09T10:00:00Z');
 const obs=new MarketObserver({clock:()=>now,fetchFn:async()=>({ok:true,json:async()=>({collections:{snowglobes:{name:'Snow Globes',days:[['2026-11-09',8,9]]}}})})});
 return obs.updateFloors().then(()=>{assert.equal(obs.giftFloor('Snow Globe').floorTon,'8');assert.equal(obs.giftFloor('Unlisted Gift').available,false)});
});
