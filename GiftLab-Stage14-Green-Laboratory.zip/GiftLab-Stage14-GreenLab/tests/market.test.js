'use strict';
const test=require('node:test');const assert=require('node:assert/strict');
const {MarketObserver,parseDaily,quote,decimalToUnits}=require('../market');
const DAY='2026-11-09';const NOW=Date.parse(DAY+'T09:00:00Z');
const dataset={generated:DAY+'T08:00:00Z',collections:{toybear:{name:'Toy Bear',days:[[DAY,6.5,3]]},plushpepe:{name:'Plush Pepe',days:[[DAY,3800,2]]},empty:{name:'Empty',days:[]},malformed:{name:'Bad',days:[[DAY,0,0]]}}};
test('floor parser uses collection-wide daily observations, not issue price or models',()=>{
 const result=parseDaily(dataset,NOW);assert.equal(result.length,2);
 assert.equal(result.find(p=>p.slug==='toybear').floorTon,'6.5');
 assert.equal(result.find(p=>p.slug==='plushpepe').floorTon,'3800');
});
test('no fabricated floor when missing or invalid',()=>{assert.deepEqual(parseDaily({collections:{x:{days:[]}}},NOW),[]);assert.throws(()=>parseDaily({}),/schema/)});
test('5% demo bonus once, exact decimal math',()=>{
 const q=quote('10','2.4','0.024');assert.equal(q.amountTon,'10');assert.equal(q.bonusTon,'0.5');assert.equal(q.totalTon,'10.5');assert.equal(q.baseInternalStars,'1000');assert.equal(q.bonusInternalStars,'50');assert.equal(q.totalInternalStars,'1050');assert.equal(q.realPaymentsEnabled,false);
 assert.equal(quote('0.1','2.4','0.024').totalInternalStars,'10.5');
});
test('no automatic Stars conversion without configured internal rate',()=>{assert.equal(quote('1', '2', null).totalInternalStars,undefined);assert.throws(()=>decimalToUnits('-1'),/неотрицательное/)});
test('upstream failures report errors and never invent prices',async()=>{const observer=new MarketObserver({clock:()=>NOW,fetchFn:async()=>{throw Error('offline')}});assert.equal(await observer.updateFloors(),false);assert.equal(observer.view().total,0);assert.equal(observer.view().errors[0].source,'floors')});
test('valid data is cached in memory and rate conversion is enabled only by explicit setup',async()=>{
 const observer=new MarketObserver({clock:()=>NOW,starUsd:'0.02',fetchFn:async url=>({ok:true,json:async()=>url.includes('coingecko')?{'the-open-network':{usd:2,last_updated_at:NOW/1000}}:dataset})});
 assert.equal(await observer.updateFloors(),true);assert.equal(await observer.updateRates(),true);
 const v=observer.view('toy');assert.equal(v.items.length,1);assert.equal(v.items[0].internalStars,'650');assert.equal(observer.estimate('2').totalInternalStars,'210');
});
