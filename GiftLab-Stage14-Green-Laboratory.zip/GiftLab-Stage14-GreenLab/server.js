/**
 * GIFT LAB – learning prototype only.
 * No real money, no Telegram gifts transfers, no redeemable assets.
 * Node.js >= 20, zero npm dependencies.
 */
'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {MarketObserver} = require('./market');
const XTR = require('./xtr-support');

const PORT = Number(process.env.PORT || 3000);
const TOKEN = process.env.BOT_TOKEN || '';
const DEMO_MODE = !TOKEN && process.env.NODE_ENV !== 'production';
const XTR_TEST_MODE=process.env.XTR_TEST_MODE==='1';
const XTR_SUPPORT_ENABLED=Boolean(TOKEN)&&process.env.ENABLE_XTR_SUPPORT==='1';
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA_DIR = process.env.GIFT_LAB_DATA_DIR ? path.resolve(process.env.GIFT_LAB_DATA_DIR) : path.join(ROOT, 'data');
const DATA_FILE = path.join(DATA_DIR, 'game.json');
const market = new MarketObserver({cacheDir:DATA_DIR});

// Original regular Telegram gift icons, separate from collectible collection artwork.
// Regular catalog & gift IDs: https://giftclub.app/telegram-gifts
// Prices below are NON-MARKET DEMO VALUES, not live floors; market snapshots are separate and sourced in market.js
// All prizes here are NON-REDEEMABLE simulations; collectible preview != NFT ownership.
const REGULAR_GIFTS = [
  {id:"regular-heart",name:"Сердечко",emoji:"❤️",value:15,telegramGiftId:"5170145012310081615",rarity:"common",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/heart-Ctwp_dgm.webp"},
  {id:"regular-bear",name:"Мишка",emoji:"🧸",value:15,telegramGiftId:"5170233102089322756",rarity:"common",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/teddy-P7L5OrDb.webp"},
  {id:"regular-box",name:"Подарочная коробка",emoji:"🎁",value:25,telegramGiftId:"5170250947678437525",rarity:"common",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/present-DU3mLWq7.webp"},
  {id:"regular-rose",name:"Роза",emoji:"🌹",value:25,telegramGiftId:"5168103777563050263",rarity:"common",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/rose-DzaGCbdt.webp"},
  {id:"regular-cake",name:"Торт",emoji:"🎂",value:50,telegramGiftId:"5170144170496491616",rarity:"rare",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/cake-CDyE7Zg1.webp"},
  {id:"regular-flowers",name:"Букет",emoji:"💐",value:50,telegramGiftId:"5170314324215857265",rarity:"rare",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/flowers-B9LjJSGo.webp"},
  {id:"regular-rocket",name:"Ракета",emoji:"🚀",value:50,telegramGiftId:"5170564780938756245",rarity:"rare",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/rocket-Bscr0ZRS.webp"},
  {id:"regular-champagne",name:"Шампанское",emoji:"🍾",value:50,telegramGiftId:"6028601630662853006",rarity:"rare",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/champagne-CohRgXQZ.webp"},
  {id:"regular-trophy",name:"Кубок",emoji:"🏆",value:100,telegramGiftId:"5168043875654172773",rarity:"epic",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/trophy-Bca8j4hu.webp"},
  {id:"regular-ring",name:"Кольцо",emoji:"💍",value:100,telegramGiftId:"5170690322832818290",rarity:"epic",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/ring-4Vo2jNjo.webp"},
  {id:"regular-gem",name:"Бриллиант",emoji:"💎",value:100,telegramGiftId:"5170521118301225164",rarity:"epic",kind:"regular",priceType:"fixed",image:"https://giftclub.app/assets/diamond-CPsrfxm4.webp"}
];
const COLLECTIBLE_PREVIEWS = [
  {id:"nft-lolpop",name:"Lol Pop",emoji:"🍭",value:291,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/lolpop/thumb.webp"},
  {id:"nft-bdaycandle",name:"B-Day Candle",emoji:"🕯️",value:325,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/bdaycandle/thumb.webp"},
  {id:"nft-cookieheart",name:"Cookie Heart",emoji:"💝",value:351,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/cookieheart/thumb.webp"},
  {id:"nft-homemadecake",name:"Homemade Cake",emoji:"🎂",value:365,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/homemadecake/thumb.webp"},
  {id:"nft-eternalcandle",name:"Eternal Candle",emoji:"🕯️",value:437,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/eternalcandle/thumb.webp"},
  {id:"nft-snowglobe",name:"Snow Globe",emoji:"❄️",value:466,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/snowglobe/thumb.webp"},
  {id:"nft-jellybunny",name:"Jelly Bunny",emoji:"🐰",value:601,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/jellybunny/thumb.webp"},
  {id:"nft-lovecandle",name:"Love Candle",emoji:"🕯️",value:783,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/lovecandle/thumb.webp"},
  {id:"nft-recordplayer",name:"Record Player",emoji:"🎼",value:843,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/recordplayer/thumb.webp"},
  {id:"nft-madpumpkin",name:"Mad Pumpkin",emoji:"🎃",value:897,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/madpumpkin/thumb.webp"},
  {id:"nft-luckylocket",name:"Lucky Locket",emoji:"💜",value:1037,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/luckylocket/thumb.webp"},
  {id:"nft-trappedheart",name:"Trapped Heart",emoji:"❤️",value:1181,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/trappedheart/thumb.webp"},
  {id:"nft-electricskull",name:"Electric Skull",emoji:"💀",value:1750,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/electricskull/thumb.webp"},
  {id:"nft-eternalrose",name:"Eternal Rose",emoji:"🌹",value:1830,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/eternalrose/thumb.webp"},
  {id:"nft-toybear",name:"Toy Bear",emoji:"🧸",value:2383,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/toybear/thumb.webp"},
  {id:"nft-voodoodoll",name:"Voodoo Doll",emoji:"🪆",value:2560,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/voodoodoll/thumb.webp"},
  {id:"nft-kissedfrog",name:"Kissed Frog",emoji:"🐸",value:3344,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/kissedfrog/thumb.webp"},
  {id:"nft-magicpotion",name:"Magic Potion",emoji:"🧪",value:3386,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/magicpotion/thumb.webp"},
  {id:"nft-iongem",name:"Ion Gem",emoji:"💎",value:4214,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/iongem/thumb.webp"},
  {id:"nft-perfumebottle",name:"Perfume Bottle",emoji:"🧴",value:4656,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/perfumebottle/thumb.webp"},
  {id:"nft-mightyarm",name:"Mighty Arm",emoji:"💪",value:6670,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/mightyarm/thumb.webp"},
  {id:"nft-astralshard",name:"Astral Shard",emoji:"✨",value:7827,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/astralshard/thumb.webp"},
  {id:"nft-lootbag",name:"Loot Bag",emoji:"💰",value:8455,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/lootbag/thumb.webp"},
  {id:"nft-durovsglasses",name:"Durov\u2019s Glasses",emoji:"🕶️",value:8772,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/durovsglasses/thumb.webp"},
  // The following are real named Telegram gift collections, with NON-MARKET DEMO valuations.
  // Fresh observed floor data and TON/USD conversion remain separate until verified.
  {id:"nft-plushpepe",name:"Plush Pepe",emoji:"🐸",value:12500,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/plushpepe/thumb.webp"},
  {id:"nft-snoopdogg",name:"Snoop Dogg",emoji:"🐕",value:1000,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/snoopdogg/thumb.webp"},
  {id:"nft-snoopcigar",name:"Snoop Cigar",emoji:"🚬",value:1200,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/snoopcigar/thumb.webp"},
  {id:"nft-lowrider",name:"Low Rider",emoji:"🚘",value:1700,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/lowrider/thumb.webp"},
  {id:"nft-swagbag",name:"Swag Bag",emoji:"👜",value:2400,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/swagbag/thumb.webp"},
  {id:"nft-westsidesign",name:"Westside Sign",emoji:"🤘",value:3400,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/westsidesign/thumb.webp"},
  {id:"nft-xmasstocking",name:"Xmas Stocking",emoji:"🧦",value:300,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/xmasstocking/thumb.webp"},
  {id:"nft-candycane",name:"Candy Cane",emoji:"🍬",value:350,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/candycane/thumb.webp"},
  {id:"nft-santahat",name:"Santa Hat",emoji:"🎅",value:450,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/santahat/thumb.webp"},
  {id:"nft-snowmittens",name:"Snow Mittens",emoji:"🧤",value:520,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/snowmittens/thumb.webp"},
  {id:"nft-jinglebells",name:"Jingle Bells",emoji:"🔔",value:640,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/jinglebells/thumb.webp"},
  {id:"nft-winterwreath",name:"Winter Wreath",emoji:"❄️",value:760,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/winterwreath/thumb.webp"},
  {id:"nft-gingercookie",name:"Ginger Cookie",emoji:"🍪",value:900,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/gingercookie/thumb.webp"},
  {id:"nft-holidaydrink",name:"Holiday Drink",emoji:"☕",value:420,rarity:"epic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/holidaydrink/thumb.webp"},
  {id:"nft-durovscap",name:"Durov's Cap",emoji:"🧢",value:7500,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/durovscap/thumb.webp"},
  {id:"nft-swisswatch",name:"Swiss Watch",emoji:"⌚",value:1700,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/swisswatch/thumb.webp"},
  {id:"nft-diamondring",name:"Diamond Ring",emoji:"💍",value:2300,rarity:"legendary",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/diamondring/thumb.webp"},
  {id:"nft-rarebird",name:"Rare Bird",emoji:"🦜",value:4200,rarity:"mythic",kind:"collectible-preview",priceType:"demo-catalogue",image:"https://fragment.com/file/gifts/rarebird/thumb.webp"}
];
// Stage 7: playable ⭐ rewards are DEMO balance credits, not Telegram Stars.
const DEMO_STAR_REWARDS=[1,3,5,10,15,20,25,30,40,50,60,75,100,125,150,175,200,250,300,350,400,500,600,650,750,900,1000,1200,1500,1800,2000,2500,3000,3500,4000,5000,6500].map(value=>({id:'stars-'+value,name:`${value} демо-звёзд`,value,emoji:'⭐',rarity:'common',kind:'stars',priceType:'demo',image:''}));
const CATALOG=[...REGULAR_GIFTS,...COLLECTIBLE_PREVIEWS,...DEMO_STAR_REWARDS];
// Each theme has an intentionally curated prize pool. Every high tier has 8+ collectible references.
// Probabilities are computed server side and disclosed via /api/cases / the fairness panel.
const CASE_CONFIG=[
 ['starter','Signal / Начало',25,'#38bdf8','📡','starter',['regular-heart','regular-bear','regular-box','regular-rose','regular-cake','regular-rocket','nft-lolpop']],
 ['lucky','Lucky Drop',50,'#14b8a6','✨','neon',['regular-bear','regular-heart','regular-rose','regular-box','regular-rocket','regular-gem','regular-trophy','nft-lolpop']],
 ['gift','Telegram Pulse',100,'#a78bfa','💬','telegram',['regular-box','regular-rose','regular-rocket','regular-gem','stars-50','stars-75','nft-lolpop','nft-cookieheart','nft-bdaycandle']],
 ['bloom','Rose Circuit',150,'#fb7185','💗','pink',['regular-flowers','regular-gem','regular-ring','stars-75','stars-100','nft-lolpop','nft-cookieheart','nft-homemadecake','nft-eternalcandle']],
 ['premium','Durov Protocol',250,'#64b5ff','✈️','telegram',['stars-100','stars-150','regular-gem','nft-lolpop','nft-bdaycandle','nft-cookieheart','nft-homemadecake','nft-snowglobe','nft-jellybunny','nft-eternalcandle']],
 ['neon','Black Vault',350,'#a78bfa','🖤','black',['stars-100','stars-200','nft-lolpop','nft-cookieheart','nft-snowglobe','nft-eternalcandle','nft-jellybunny','nft-recordplayer','nft-lovecandle','nft-madpumpkin']],
 ['legendary','Сигнал MAX',500,'#facc15','📶','telegram',['stars-100','stars-250','nft-lolpop','nft-bdaycandle','nft-cookieheart','nft-homemadecake','nft-eternalcandle','nft-snowglobe','nft-jellybunny','nft-lovecandle','nft-recordplayer','nft-trappedheart']],
 ['vault','Winter Orbit',750,'#67e8f9','❄️','winter',['stars-200','stars-350','nft-lolpop','nft-snowglobe','nft-jellybunny','nft-lovecandle','nft-recordplayer','nft-madpumpkin','nft-luckylocket','nft-trappedheart','nft-electricskull']],
 ['nova','Neon Rush',1000,'#818cf8','🌌','neon',['stars-300','stars-500','nft-eternalcandle','nft-jellybunny','nft-lovecandle','nft-recordplayer','nft-madpumpkin','nft-luckylocket','nft-trappedheart','nft-electricskull','nft-eternalrose','nft-toybear']],
 ['royal','Мажорный чат',1500,'#e879f9','👑','royal',['stars-500','stars-750','nft-recordplayer','nft-madpumpkin','nft-luckylocket','nft-trappedheart','nft-electricskull','nft-eternalrose','nft-toybear','nft-voodoodoll','nft-kissedfrog','nft-magicpotion']],
 ['mythic','Дуровский вайб',2000,'#f472b6','🕶️','telegram',['stars-650','stars-1000','nft-luckylocket','nft-trappedheart','nft-electricskull','nft-eternalrose','nft-toybear','nft-voodoodoll','nft-kissedfrog','nft-magicpotion','nft-iongem','nft-durovsglasses']],
 ['cosmos','Полярная ночь',2500,'#38bdf8','🌙','winter',['stars-750','stars-1200','nft-trappedheart','nft-electricskull','nft-eternalrose','nft-toybear','nft-voodoodoll','nft-kissedfrog','nft-magicpotion','nft-iongem','nft-perfumebottle','nft-astralshard']],
 ['elite','Black Label',3000,'#c4b5fd','♠️','black',['stars-900','stars-1500','nft-electricskull','nft-eternalrose','nft-toybear','nft-voodoodoll','nft-kissedfrog','nft-magicpotion','nft-iongem','nft-perfumebottle','nft-mightyarm','nft-durovsglasses']],
 ['diamond','Глянцевый мороз',3500,'#7dd3fc','💎','winter',['stars-1000','stars-1800','nft-electricskull','nft-eternalrose','nft-toybear','nft-voodoodoll','nft-kissedfrog','nft-magicpotion','nft-iongem','nft-perfumebottle','nft-mightyarm','nft-astralshard']],
 ['exclusive','Royal Signal',4000,'#fda4af','🔥','royal',['stars-1200','stars-2000','nft-eternalrose','nft-toybear','nft-voodoodoll','nft-kissedfrog','nft-magicpotion','nft-iongem','nft-perfumebottle','nft-mightyarm','nft-astralshard','nft-lootbag']],
 ['ultimate','Collector Prime',5000,'#fde68a','🏛️','royal',['stars-1500','stars-2500','nft-voodoodoll','nft-kissedfrog','nft-magicpotion','nft-iongem','nft-perfumebottle','nft-mightyarm','nft-astralshard','nft-lootbag','nft-durovsglasses','nft-toybear']],
 ['micro','Three Wishes',40,'#a78bfa','✧','black',['stars-1','stars-3','nft-snoopdogg']],
 ['snoop','Snoop’s Vault',2400,'#b77bf7','✦','snoop',['nft-snoopdogg','nft-snoopcigar','nft-lowrider','nft-swagbag','nft-westsidesign']],
 ['newyear','Midnight 2027',780,'#8ddcff','❆','winter',['nft-xmasstocking','nft-candycane','nft-santahat','nft-snowmittens','nft-jinglebells','nft-winterwreath','nft-gingercookie','nft-holidaydrink','nft-snowglobe']],
 ['pepe','Pepe Royale',4800,'#62dda9','♛','pepe',['stars-1200','stars-1500','nft-kissedfrog','nft-iongem','nft-perfumebottle','nft-durovscap','nft-plushpepe','nft-diamondring','nft-rarebird','nft-mightyarm']],
 ['durovex','Durov Legacy',3500,'#56c5fd','◇','telegram',['nft-durovsglasses','nft-durovscap','nft-astralshard','nft-lootbag','nft-mightyarm','nft-iongem','nft-swisswatch','nft-diamondring']],
 ['holidaymini','Snowfall',300,'#8de9fe','❄','winter',['nft-xmasstocking','nft-candycane','nft-santahat','nft-holidaydrink','nft-snowmittens','nft-jinglebells','nft-snowglobe','stars-100']]
];
// Solve a monotonically declining distribution for an ~86% expected demo payout.
// All rewards get at least 0.01%; outcomes are never reweighted for particular users.
function balancedDrops(ids,cost,lookup=CATALOG){
 const items=ids.map(id=>{const it=lookup.find(x=>x.id===id);if(!it)throw new Error('Missing catalog item '+id);return it;});
 const target=.86*cost, n=items.length, total=10000, min=1;
 const weights=(lambda)=>{
  const logs=items.map(i=>-lambda*i.value/cost), max=Math.max(...logs);
  const exps=logs.map(x=>Math.exp(Math.max(-700,x-max))), sum=exps.reduce((a,b)=>a+b,0);
  const remaining=total-n*min, raw=exps.map(x=>x/sum*remaining), nums=raw.map(x=>Math.floor(x)+min);
  let rem=total-nums.reduce((a,b)=>a+b,0);
  const order=raw.map((v,i)=>({i,f:v-Math.floor(v)})).sort((a,b)=>b.f-a.f);
  for(let i=0;i<rem;i++)nums[order[i].i]++;
  return nums;
 };
 let low=-100,high=100;
 for(let k=0;k<70;k++){const mid=(low+high)/2,w=weights(mid);const ev=w.reduce((a,v,i)=>a+v*items[i].value/total,0);if(ev>target)low=mid;else high=mid;}
 return ids.map((id,i)=>[id,weights((low+high)/2)[i]]);
}
const CASES=CASE_CONFIG.map(([id,name,cost,color,symbol,theme,items])=>({id,name,cost,color,symbol,theme,drops:balancedDrops(items,cost)}));
for(const c of CASES){
 if(c.drops.reduce((sum,p)=>sum+p[1],0)!==10000)throw new Error('Case probabilities must be 100%: '+c.id);
 if(c.drops.some(([id])=>!CATALOG.some(it=>it.id===id)))throw new Error('Unknown case item '+c.id);
 if(c.cost>=500 && !['snoop','newyear','pepe','durovex','holidaymini'].includes(c.id) && c.drops.filter(([id])=>id.startsWith('nft-')).length<8)throw new Error('Premium case needs 8+ collectibles');
}
// STAGE 10: A collectible is offered in new demo drops ONLY if its collection
// has a fresh observed floor AND an administrator-defined internal star unit.
// Zero values, missing prices, stale FX and unpublished collections never get invented prices.
const STAR_DEMO_FEE_PERCENT=2; // visible sandbox processing fee, NOT an official Telegram fee
function pricedCollectibles(){
  const fx=market.rate;
  if(!market.starUsd||!fx||fx.stale||Date.now()-Date.parse(fx.updatedAt)>3600000)return [];
  const rate=Number(fx.tonUsd)/Number(market.starUsd);
  if(!Number.isFinite(rate)||rate<=0)return [];
  return COLLECTIBLE_PREVIEWS.flatMap(it=>{
    const floor=market.giftFloor(it.name);
    if(!floor.available)return [];
    const value=Math.floor(Number(floor.floorTon)*rate*0.98); // explicit 2% demonstration valuation margin
    if(!Number.isSafeInteger(value)||value<1||value>100000000)return [];
    return [{...it,value,priceType:'observed-floor-2%-demo',floorTon:floor.floorTon,floorSource:floor.source,observedAt:floor.observedAt}];
  });
}
// Stage 11: retain all collection ARTWORK and demo valuation in NON-REDEEMABLE play.
// No unsourced values are ever presented as live market floors. Market/deposit
// quotes remain strictly separate and require a fresh observed price.
function activeCatalog(){
  const observed=new Map(pricedCollectibles().map(i=>[i.id,i]));
  return [...REGULAR_GIFTS,...COLLECTIBLE_PREVIEWS.map(i=>observed.get(i.id)||i),...DEMO_STAR_REWARDS];
}
function activeCases(){
  const catalog=activeCatalog();
  return CASE_CONFIG.map(([id,name,cost,color,symbol,theme,configured])=>{
    const base=[...configured];
    // Non-redeemable star prizes complement rather than replace collectibles.
    const targets=[0.15,0.30,0.50,0.75,1.0,1.25];
    const stars=DEMO_STAR_REWARDS.map(x=>x.value);
    if(!['micro','snoop','newyear','pepe','durovex','holidaymini'].includes(id))for(const mult of targets){
      const wanted=cost*mult;
      const nearest=stars.reduce((a,b)=>Math.abs(a-wanted)<Math.abs(b-wanted)?a:b);
      const key='stars-'+nearest;if(!base.includes(key))base.push(key);
    }
    return {id,name,cost,color,symbol,theme,drops:balancedDrops(base,cost,catalog)};
  });
}

const STAKES = [25,100,500,1000,5000];
const MAX_DEMO_STAKE = 100000;
const PRICE_SNAPSHOT='SIMULATED NON-REDEEMABLE VALUES — NOT LIVE FLOOR';
const ROCKET_WAIT_MS = Math.max(100,Math.min(60000,Number(process.env.ROCKET_WAIT_MS)||10000));
const sessions = new Map();
const recentOpens = new Map(); // защита от повторной отправки: тот же requestId не списывает звёзды второй раз

fs.mkdirSync(DATA_DIR,{recursive:true});
let state;
try {
  state = JSON.parse(fs.readFileSync(DATA_FILE,'utf8'));
  if (!state || typeof state !== 'object' || !state.users || !state.rooms) throw Error('Invalid state');
} catch (err) {
  if (fs.existsSync(DATA_FILE)) throw new Error('Cannot read game.json; refusing to overwrite saved data: '+ err.message);
  state = {users:{},rooms:{},events:[],rocket:{},mines:{}};
}

state.events ||= [];
state.rocket ||= {};
state.mines ||= {};
state.depositJournal ||= {};
state.supportOrders ||= {};
state.supportCharges ||= {};
state.supportUpdateOffset ||= 0;
// Global shared demo Rocket round. Prior per-user rocket save data is preserved but unused.
state.rocketGame ||= null;
state.rocketLastCrash ||= null;
function persist() {
  const temp = DATA_FILE+'.tmp';
  fs.writeFileSync(temp,JSON.stringify(state,null,2));
  fs.renameSync(temp,DATA_FILE);
}
function normalizeUser(u){for(const it of u.inventory||[]){const ref=CATALOG.find(x=>x.id===it.id);if(ref){Object.assign(it,{image:ref.image,name:ref.name,emoji:ref.emoji,kind:ref.kind,priceType:ref.priceType,rarity:ref.rarity});}else if(/^(starter|lucky|gift|premium|legendary)-\d+$/.test(it.id)){it.name='Архивный приз Stage 5';it.emoji='🎁';it.image='';it.kind='legacy';}}u.createdAt=u.createdAt||new Date().toISOString();u.lastBonus=u.lastBonus||0;u.username=u.username||'';u.photo=u.photo||'';u.stats=Object.assign({cases:0,items:0,upgrades:0,pvp:0,spent:0,sales:0,earned:0,gameWins:0},u.stats);}
for(const u of Object.values(state.users))normalizeUser(u);
function pickByWeight(drops,lookup=CATALOG) {
  const total = drops.reduce((s,entry) => s+entry[1],0);
  const roll = crypto.randomInt(total);
  let acc=0;
  for (const [id, weight] of drops) { acc+=weight; if (roll<acc) return lookup.find(v=>v.id===id); }
  throw new Error('Invalid drop table');
}
function event(user,metric,amount=1){
  state.events.push({id:user.id,metric,amount,time:Date.now()});
  if(state.events.length>12000) state.events=state.events.slice(-12000);
}
function addHistory(user,type,message,delta,extra={}) {
  user.history.unshift({id:crypto.randomUUID(),time:new Date().toISOString(),type,message,delta:delta||0,...extra});
  user.history = user.history.slice(0,30);
}
const START_STARS = 12000, DAILY_BONUS = 5000, BONUS_COOLDOWN = 3600e3;
function getUser(id,name,extra={}){
  let u=state.users[id];
  if(!u){u=state.users[id]={id,name,balance:START_STARS,inventory:[],history:[]};addHistory(u,'bonus','Стартовый бонус',START_STARS);}
  u.name=name;u.username=extra.username||'';u.photo=extra.photo||'';
  normalizeUser(u);persist();return u;
}
function sanitizedUser(user){
  return {id:user.id,name:user.name,username:user.username||'',photo:user.photo||'',createdAt:user.createdAt,balance:user.balance,stats:user.stats,nextBonus:user.lastBonus+BONUS_COOLDOWN,inventory:user.inventory.map(x=>({...x})),history:user.history.slice(0,15),labSupporter:!!user.labSupporter};
}
function validInitData(raw){
  if (!TOKEN || typeof raw!=='string' || raw.length>8192) return null;
  const params = new URLSearchParams(raw);
  const hash = params.get('hash');
  if (!hash || !/^[a-f\d]{64}$/i.test(hash)) return null;
  params.delete('hash');
  // 'signature' belongs to Telegram's third-party Ed25519 validation flow.
  params.delete('signature');
  const authDate = Number(params.get('auth_date'));
  const now = Date.now()/1000;
  if (!Number.isInteger(authDate) || authDate>now+30 || now-authDate>86400) return null;
  const dataCheckString=[...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
  const secret=crypto.createHmac('sha256','WebAppData').update(TOKEN).digest();
  const digest=crypto.createHmac('sha256',secret).update(dataCheckString).digest();
  if(!crypto.timingSafeEqual(digest,Buffer.from(hash,'hex'))) return null;
  let telegramUser;
  try { telegramUser=JSON.parse(params.get('user')||'null'); } catch {return null;}
  if(!telegramUser || !Number.isSafeInteger(telegramUser.id)) return null;
  const photo=typeof telegramUser.photo_url==='string'&&/^https:\/\/t\.me\//.test(telegramUser.photo_url)?telegramUser.photo_url.slice(0,300):'';
  return {id:`tg:${telegramUser.id}`,name:String(telegramUser.first_name||telegramUser.username||'Игрок').slice(0,32),username:String(telegramUser.username||'').slice(0,32),photo};
}
function response(res,status,data){
  const body=JSON.stringify(data);
  res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
  res.end(body);
}
function bad(message,status=400){const err=new Error(message);err.status=status;throw err;}
function bodyJson(req){
  return new Promise((resolve,reject)=>{
    let text='';
    req.on('data',chunk=>{text+=chunk;if(text.length>16000){reject(Object.assign(new Error('Слишком большой запрос'),{status:413}));req.destroy();}});
    req.on('end',()=>{try{resolve(text?JSON.parse(text):{});}catch{reject(Object.assign(new Error('Неверный JSON'),{status:400}));}});
    req.on('error',reject);
  });
}
function currentUser(req){
  const match=/^Bearer\s+(\S+)$/i.exec(req.headers.authorization||'');
  const session=match&&sessions.get(match[1]);
  if(!session || session.expires<Date.now()) bad('Требуется вход в приложение',401);
  const user=state.users[session.userId];
  if(!user) bad('Пользователь не найден',401);
  return user;
}
function serveStatic(req,res,url){
  const fileName=url.pathname==='/'?'index.html':url.pathname.slice(1);
  // Only packaged case artwork is exposed, never arbitrary files or paths.
  const allowedPage=['index.html','style.css','app.js'].includes(fileName);
  const allowedArtwork=/^assets\/cases\/[a-z0-9_-]+\.webp$/.test(fileName);
  const allowedLabArt=/^assets\/lab\/[a-z0-9_-]+\.svg$/.test(fileName);
  if(!allowedPage&&!allowedArtwork&&!allowedLabArt) return response(res,404,{error:'Страница не найдена'});
  const fullPath=path.join(PUBLIC,fileName);
  if(!fs.existsSync(fullPath)) return response(res,404,{error:'Изображение не найдено'});
  const contentType=fileName.endsWith('.webp')?'image/webp':fileName.endsWith('.svg')?'image/svg+xml':fileName.endsWith('.html')?'text/html; charset=utf-8':fileName.endsWith('.css')?'text/css; charset=utf-8':'application/javascript; charset=utf-8';
  res.writeHead(200,{'Content-Type':contentType,'X-Content-Type-Options':'nosniff','Cache-Control':'no-cache','Content-Security-Policy':"default-src 'self'; script-src 'self' https://telegram.org; style-src 'self'; style-src-attr 'unsafe-inline'; img-src 'self' data: https://t.me https://fragment.com https://nft.fragment.com https://giftclub.app https://denzyve.github.io; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'self' https://web.telegram.org https://replit.com https://*.replit.com"});
  fs.createReadStream(fullPath).pipe(res);
}
// Time-based round state survives restarts and doesn't rely on client clocks.
function rocketMultiplier(elapsed){return +Math.exp(Math.max(0,elapsed)/9000).toFixed(2);}
function makeRocketRound(startAt){
  const n=crypto.randomInt(1000000)/1000000;
  const crashAt=Math.max(1.2,Math.min(8,+(0.97/(1-n)).toFixed(2)));
  return {id:crypto.randomUUID(),startAt,crashAt,crashAfter:Math.ceil(9000*Math.log(crashAt)),bets:{}};
}
function syncRocketRound(){
  const now=Date.now();
  if(!state.rocketGame){state.rocketGame=makeRocketRound(now+ROCKET_WAIT_MS);persist();}
  const r=state.rocketGame;
  const end=r.startAt+r.crashAfter;
  if(now>=end){
    for(const [id,bet] of Object.entries(r.bets)) if(!bet.cashed){
      const owner=state.users[id];
      if(owner)addHistory(owner,'rocket',`Rocket: взрыв на x${r.crashAt.toFixed(2)}`);
    }
    state.rocketLastCrash={id:r.id,at:end,crashAt:r.crashAt};
    state.rocketGame=makeRocketRound(now+ROCKET_WAIT_MS);
    persist();
  }
  return state.rocketGame;
}
function rocketView(r,user){
  const now=Date.now(),phase=now<r.startAt?'waiting':'active';
  const bet=r.bets[user.id]||null;
  return {id:r.id,status:phase,startAt:r.startAt,remainingMs:Math.max(0,r.startAt-now),
    started:r.startAt,current:phase==='waiting'?1:rocketMultiplier(now-r.startAt),
    crashAt:null,stake:bet?.stake||0,payout:bet?.payout||0,hasBet:!!bet,cashed:!!bet?.cashed,
    lastCrash:state.rocketLastCrash};
}
const server=http.createServer(async(req,res)=>{
  try {
    const url=new URL(req.url||'/',`http://${req.headers.host||'localhost'}`);
    if(req.method==='GET' && !url.pathname.startsWith('/api/')) return serveStatic(req,res,url);
    if(req.method==='GET' && url.pathname==='/api/health') return response(res,200,{ok:true,mode:DEMO_MODE?'demo':TOKEN?'telegram':'disabled'});
    if(req.method==='GET' && url.pathname==='/api/market') return response(res,200,market.view(url.searchParams.get('q')||''));
    if(req.method==='GET' && url.pathname==='/api/market/quote'){try{return response(res,200,market.estimate(url.searchParams.get('ton')||''));}catch(e){return response(res,400,{error:e.message});}}
    // Public metadata is read-only. Prices are historical observed floors, never guaranteed executable quotes.
    if(req.method==='GET' && url.pathname==='/api/market/case-coverage') {
      const gifts=COLLECTIBLE_PREVIEWS.map(it=>({id:it.id,name:it.name,...market.giftFloor(it.name)}));
      return response(res,200,{items:gifts,known:gifts.filter(g=>g.available).length,total:gifts.length,source:market.view().source,realPaymentsEnabled:false});
    }
    if(req.method==='GET' && url.pathname==='/api/support/config') return response(res,200,{enabled:XTR_SUPPORT_ENABLED,product:XTR.PRODUCT,mode:XTR_TEST_MODE?'test':'live',gamingBalanceSeparate:true});
    if(req.method==='GET' && url.pathname==='/api/catalog') {
      return response(res,200,{items:activeCatalog(),cases:activeCases().map(c=>({...c,drops:c.drops.map(([id,weight])=>({id,percent:weight/100}))})),stakes:STAKES,demo:DEMO_MODE,priceSnapshot:PRICE_SNAPSHOT,maxDemoStake:MAX_DEMO_STAKE});
    }
    if(req.method==='POST' && url.pathname==='/api/auth'){
      const body=await bodyJson(req);
      let identity=validInitData(body.initData);
      if(!identity && DEMO_MODE && typeof body.demoName==='string'){
        const name=body.demoName.trim().slice(0,24);
        if(name.length<2||!/^[\p{L}\p{N}_ -]+$/u.test(name))bad('Введите имя от 2 до 24 букв или цифр');
        identity={id:'demo:'+name.toLowerCase(),name};
      }
      if(!identity) bad('Неверные данные Telegram. Откройте Mini App из бота.',401);
      const user=getUser(identity.id,identity.name,identity);
      // Initial demo names must not be treated as secure authentication.
      const sessionToken=crypto.randomBytes(32).toString('hex');
      sessions.set(sessionToken,{userId:user.id,expires:Date.now()+1000*60*60*24});
      if(sessions.size>10000){for(const [key,value] of sessions) if(value.expires<Date.now())sessions.delete(key);}
      return response(res,200,{token:sessionToken,user:sanitizedUser(user)});
    }
    if(url.pathname.startsWith('/api/')) {
      const user=currentUser(req);
      if(req.method==='GET' && url.pathname==='/api/me') return response(res,200,{user:sanitizedUser(user)});
      // Real XTR purchases ONLY buy a permanent nontransferable supporter profile badge.
      // They never top up the balance that is used for random games.
      if(req.method==='GET'&&url.pathname==='/api/support/status'){
        const orders=Object.values(state.supportOrders).filter(o=>o.userId===user.id).sort((a,b)=>b.createdAt-a.createdAt);
        return response(res,200,{enabled:XTR_SUPPORT_ENABLED,labSupporter:!!user.labSupporter,lastOrder:orders[0]?{id:orders[0].id,status:orders[0].status,amount:orders[0].amount}:null,product:XTR.PRODUCT});
      }
      if(req.method==='POST'&&url.pathname==='/api/support/invoice'){
        await bodyJson(req);
        if(!XTR_SUPPORT_ENABLED)bad('Telegram Stars checkout не включён. Для теста нужен Telegram Test Bot и ENABLE_XTR_SUPPORT=1.',503);
        const order=XTR.startOrder(state,user);persist();
        const invoice=await telegramBot('createInvoiceLink',{
          title:XTR.PRODUCT.title,description:XTR.PRODUCT.description,
          payload:'support:'+order.id,provider_token:'',currency:'XTR',
          prices:[{label:'Значок Lab Supporter',amount:XTR.PRODUCT.price}]
        });
        return response(res,200,{invoiceUrl:invoice,orderId:order.id,amount:order.amount,product:'Lab Supporter',notGamingBalance:true});
      }
      // Simulation only: NO Telegram invoice, blockchain wallet, transfer address, custody or real TON.
      if(req.method==='GET' && url.pathname==='/api/deposit/collections'){
        const recognized=new Map(COLLECTIBLE_PREVIEWS.map(it=>[it.name.toLowerCase().replace(/[^a-z0-9]/g,''),it]));
        const allowed=market.view().items.filter(p=>!p.stale).flatMap(p=>{
          const floor=market.giftFloor(p.name);if(!floor.available)return [];
          const ref=recognized.get(p.name.toLowerCase().replace(/[^a-z0-9]/g,''));
          return [{id:ref?.id||'catalog-'+p.slug,name:p.name,image:ref?.image||'',emoji:ref?.emoji||'✦',floorTon:floor.floorTon,observedAt:floor.observedAt,source:floor.source,discountPercent:7,creditTon:require('./market').discountFloor(floor.floorTon,7)}];
        });
        return response(res,200,{items:allowed,source:'TG Gifts / Fragment (daily observed)',verifiedOnly:true,realPaymentsEnabled:false});
      }
      if(req.method==='GET' && url.pathname==='/api/deposit/history'){
        return response(res,200,{entries:(state.depositJournal[user.id]||[]).slice(0,40),realPaymentsEnabled:false});
      }
      if(req.method==='GET' && url.pathname==='/api/deposit/quote'){
        const method=url.searchParams.get('method');
        if(method==='stars'){
          const rawAmount=url.searchParams.get('amount')||'';
          const amount=Number(rawAmount);
          if(!/^\d{1,5}$/.test(rawAmount)||!Number.isSafeInteger(amount)||amount<1||amount>50000)bad('От 1 до 50 000 демо-звёзд');
          return response(res,200,{method,kind:'sandbox',amount,bonus:0,feePercent:STAR_DEMO_FEE_PERCENT,fee:Math.ceil(amount*STAR_DEMO_FEE_PERCENT/100),total:amount-Math.ceil(amount*STAR_DEMO_FEE_PERCENT/100),unit:'demo-stars',realPaymentsEnabled:false});
        }
        if(method==='ton'){
          let quote;try{quote=market.estimate(url.searchParams.get('amount')||'');}catch(e){bad(e.message);}
          return response(res,200,{method,kind:'illustration',...quote,realPaymentsEnabled:false});
        }
        if(method==='nft'){
          const name=(url.searchParams.get('collection')||'').slice(0,90);
          const floor=market.giftFloor(name);
          if(!floor.available)bad('Нет свежей проверенной цены этой коллекции');
          return response(res,200,{method,collection:name,floor,discountPercent:7,creditTon:floor.available?require('./market').discountFloor(floor.floorTon,7):null,realPaymentsEnabled:false,transferEnabled:false});
        }
        bad('Способ не поддерживается');
      }
      if(req.method==='POST' && url.pathname==='/api/deposit/sandbox-credit'){
        if(!DEMO_MODE)bad('Тестовое зачисление отключено при Telegram-авторизации',403);
        const data=await bodyJson(req);
        if(!/^[0-9a-f-]{36}$/i.test(String(data.requestId||'')))bad('Некорректный ID');
        const amount=Number(data.amount);
        if(!Number.isSafeInteger(amount)||amount<1||amount>50000)bad('От 1 до 50 000 демо-звёзд');
        const journal=state.depositJournal[user.id] ||= [];
        let row=journal.find(x=>x.requestId===data.requestId);
        if(row){if(row.method!=='stars'||row.amount!==amount)bad('ID уже использован для другого действия',409);return response(res,200,{entry:row,user:sanitizedUser(user),replayed:true});}
        const fee=Math.ceil(amount*STAR_DEMO_FEE_PERCENT/100);const credited=amount-fee;
        row={id:crypto.randomUUID(),requestId:data.requestId,method:'stars',amount,credited,fee,feePercent:STAR_DEMO_FEE_PERCENT,bonus:0,status:'sandbox-confirmed',createdAt:new Date().toISOString(),realPayment:false};
        user.balance+=credited;journal.unshift(row);journal.splice(40);addHistory(user,'bonus',`Тестовое пополнение +${credited} демо-звёзд (комиссия ${fee})`,credited);persist();
        return response(res,200,{entry:row,user:sanitizedUser(user),replayed:false});
      }
      if(req.method==='POST' && url.pathname==='/api/deposit/nft-sandbox-request'){
        if(!DEMO_MODE)bad('Демо-заявки доступны только локально',403);
        const data=await bodyJson(req),name=String(data.collection||'').slice(0,90);
        if(!market.giftFloor(name).available)bad('Коллекция с подтверждённым флором не найдена');
        const item={name};
        if(!/^[0-9a-f-]{36}$/i.test(String(data.requestId||'')))bad('Некорректный ID');
        const journal=state.depositJournal[user.id] ||= [];
        let row=journal.find(x=>x.requestId===data.requestId);
        if(row){if(row.method!=='nft'||row.collection!==item.name)bad('ID уже использован',409);return response(res,200,{entry:row,replayed:true});}
        const floor=market.giftFloor(item.name);
        if(!floor.available)bad('Нет свежего проверенного флора; заявка недоступна');
        row={id:crypto.randomUUID(),requestId:data.requestId,method:'nft',collection:item.name,floorTon:floor.floorTon,discountPercent:7,creditTon:require('./market').discountFloor(floor.floorTon,7),status:'sandbox-pending',createdAt:new Date().toISOString(),realPayment:false};
        journal.unshift(row);journal.splice(40);persist();return response(res,200,{entry:row,replayed:false});
      }

      if(req.method==='GET' && url.pathname==='/api/leaders'){
        const period=['today','week','all'].includes(url.searchParams.get('period'))?url.searchParams.get('period'):'week';
        const metric=['earned','cases','upgrades','pvp','spent','sales','gameWins'].includes(url.searchParams.get('metric'))?url.searchParams.get('metric'):'earned';
        const now=Date.now();
        const local=new Date(now);
        const from=period==='all'?0:period==='today'
          ?new Date(local.getFullYear(),local.getMonth(),local.getDate()).getTime()
          :(()=>{const d=new Date(local.getFullYear(),local.getMonth(),local.getDate());d.setDate(d.getDate()-(d.getDay()+6)%7);return d.getTime();})();
        const totals={};
        if(period==='all') for(const u of Object.values(state.users)) totals[u.id]=u.stats[metric]||0;
        else for(const e of state.events) if(e.time>=from && e.time<=now && e.metric===metric) totals[e.id]=(totals[e.id]||0)+e.amount;
        const ranked=Object.values(state.users).map(u=>({id:u.id,name:u.name,photo:u.photo||'',value:totals[u.id]||0,isMe:u.id===user.id}))
          .sort((a,b)=>b.value-a.value||a.name.localeCompare(b.name,'ru'))
          .map((u,i)=>({...u,rank:i+1}));
        const mine=ranked.find(x=>x.isMe)||null;
        const leaders=ranked.slice(0,100);
        return response(res,200,{leaders,mine,metric,period,periodStart:from});
      }
      if(req.method==='GET' && url.pathname==='/api/recent'){
        const recent=Object.values(state.users).flatMap(u=>(u.history||[]).filter(h=>['case','upgrade','sale','pvp','rocket','mines'].includes(h.type))
          .filter(h=>h.type!=='case'||h.prizeKind!=='regular'||crypto.createHash('sha256').update(h.id).digest()[0]<128)
          .map(h=>({name:u.name,message:h.message,time:h.time,type:h.type,prizeKind:h.prizeKind||null,prizeValue:h.prizeValue||0,prizeId:h.prizeId||null})))
          .sort((a,b)=>b.time.localeCompare(a.time)).slice(0,30);
        return response(res,200,{recent,feedPolicy:'All collectible results; sample of regular results (about 50%). No generated players.'});
      }
      if(req.method==='GET' && url.pathname==='/api/rooms'){
        const rooms=Object.values(state.rooms).sort((a,b)=>b.createdAt.localeCompare(a.createdAt)).slice(0,40);
        return response(res,200,{rooms});
      }
      if(req.method==='POST' && url.pathname==='/api/cases/open'){
        const body=await bodyJson(req);
        const rid=typeof body.requestId==='string'&&/^[\w-]{8,64}$/.test(body.requestId)?user.id+':'+body.requestId:null;
        if(rid&&recentOpens.has(rid)){const cached=recentOpens.get(rid);return response(res,200,{...cached,user:sanitizedUser(user),replayed:true});}
        const box=activeCases().find(c=>c.id===body.caseId);
        if(!box)bad('Кейс не найден');
        const count=body.count===undefined?1:Number(body.count);
        if(!Number.isSafeInteger(count)||count<1||count>3)bad('За один раз можно открыть 1–3 кейса');
        const total=box.cost*count;
        if(user.balance<total)bad('Недостаточно демо-звёзд');
        const results=[];
        for(let k=0;k<count;k++){
          const prize=pickByWeight(box.drops,activeCatalog());
          if(prize.kind==='stars'){
            user.balance+=prize.value;user.stats.earned+=prize.value;event(user,'earned',prize.value);
            results.push({kind:'stars',...prize,credit:prize.value});
          }else{
            const owned={...prize,instanceId:crypto.randomUUID(),acquiredAt:new Date().toISOString()};
            user.inventory.unshift(owned);user.stats.items++;
            results.push(owned);
          }
          addHistory(user,'case',`Кейс ${box.name}: ${prize.emoji} ${prize.name}`,0,{prizeKind:prize.kind,prizeValue:prize.value,prizeId:prize.id});
        }
        user.balance-=total;user.stats.cases+=count;user.stats.spent+=total;
        event(user,'cases',count);event(user,'spent',total);
        addHistory(user,'case-cost',`Открыто ${count} × ${box.name}`,-total);
        persist();
        const payload={item:results[0],items:results,count,spent:total,user:sanitizedUser(user)};
        if(rid){recentOpens.set(rid,payload);if(recentOpens.size>500)recentOpens.delete(recentOpens.keys().next().value);}
        return response(res,200,payload);
      }
      if(req.method==='POST' && url.pathname==='/api/upgrade'){
        const body=await bodyJson(req);
        const ids=body.instanceIds===undefined?(body.instanceId?[body.instanceId]:[]):body.instanceIds;
        if(!Array.isArray(ids)||ids.length>3||new Set(ids).size!==ids.length||ids.some(x=>typeof x!=='string'))bad('Выберите от 0 до 3 разных подарков');
        const items=ids.map(id=>user.inventory.find(i=>i.instanceId===id));
        if(items.some(x=>!x))bad('Один из выбранных предметов не найден');
        const extra=body.stars===undefined?0:Number(body.stars);
        if(!Number.isSafeInteger(extra)||extra<0||extra>MAX_DEMO_STAKE)bad('Неверное число демо-звёзд');
        if(user.balance<extra)bad('Недостаточно демо-звёзд');
        const sourceValue=items.reduce((v,it)=>v+it.value,0)+extra;
        if(sourceValue<1)bad('Выберите подарки или добавьте звёзды');
        const target=activeCatalog().find(i=>i.id===body.targetId&&i.kind!=='stars');
        if(!target||target.value<=sourceValue)bad('Цель должна стоить больше суммы вложений');
        const chance=Math.min(.9,.9*sourceValue/target.value);
        const success=crypto.randomInt(1000000)/1000000<chance;
        const selected=new Set(ids);user.inventory=user.inventory.filter(i=>!selected.has(i.instanceId));user.balance-=extra;
        if(extra){user.stats.spent+=extra;event(user,'spent',extra);}
        let item=null;
        if(success){item={...target,instanceId:crypto.randomUUID(),acquiredAt:new Date().toISOString()};user.inventory.unshift(item);user.stats.upgrades++;event(user,'upgrades');}
        addHistory(user,'upgrade',success?`Апгрейд успешен → ${target.name}`:`Неудачный апгрейд → ${target.name}`,-extra);
        persist();return response(res,200,{success,chance,item,sourceValue,starsSpent:extra,itemsSpent:items.length,user:sanitizedUser(user)});
      }
      if(req.method==='POST' && url.pathname==='/api/inventory/sell'){
        const b=await bodyJson(req);
        if(typeof b.instanceId!=='string') bad('Укажите предмет');
        const index=user.inventory.findIndex(i=>i.instanceId===b.instanceId);
        if(index<0)bad('Предмет не найден в вашем инвентаре');
        const item=user.inventory[index];
        const payout=item.value; // No sell fee. Item value is virtual, not an NFT market price.
        user.inventory.splice(index,1);user.balance+=payout;
        user.stats.sales++;user.stats.earned+=payout;
        event(user,'sales');event(user,'earned',payout);
        addHistory(user,'sale',`Продан ${item.emoji} ${item.name}`,payout);
        persist();
        return response(res,200,{item,payout,user:sanitizedUser(user)});
      }
      if(req.method==='POST' && url.pathname==='/api/inventory/sell-all'){
        await bodyJson(req);
        if(!user.inventory.length)bad('Инвентарь пуст — нечего продавать');
        const items=user.inventory;
        const payout=items.reduce((s,item)=>s+item.value,0);
        const count=items.length;
        user.inventory=[];
        user.balance+=payout;
        user.stats.sales+=count;user.stats.earned+=payout;
        event(user,'sales',count);event(user,'earned',payout);
        addHistory(user,'sale',`Проданы все подарки · ${count} шт.`,payout);
        persist();
        return response(res,200,{count,payout,user:sanitizedUser(user)});
      }
      if(req.method==='POST' && url.pathname==='/api/rooms/create'){
        const body=await bodyJson(req);
        const battleCase=activeCases().find(c=>c.id===body.caseId);
        const rounds=battleCase?Math.max(1,Math.min(5,Math.floor(Number(body.rounds)||3))):0;
        const stake=battleCase?battleCase.cost*rounds:Number(body.stake);
        if(!battleCase && !STAKES.includes(stake))bad('Недопустимая ставка');
        if(user.balance<stake)bad('Недостаточно демо-звёзд');
        const active=Object.values(state.rooms).filter(r=>r.status==='waiting'&&r.creatorId===user.id).length;
        if(active>=3)bad('У вас уже есть 3 ожидающие дуэли');
        user.balance-=stake;user.stats.spent+=stake;event(user,'spent',stake);
        const room={id:crypto.randomBytes(4).toString('hex').toUpperCase(),stake,caseId:battleCase?.id||null,rounds,status:'waiting',creatorId:user.id,creatorName:user.name,joinerId:null,joinerName:null,winnerId:null,winnerName:null,createdAt:new Date().toISOString()};
        state.rooms[room.id]=room;
        addHistory(user,'pvp',`Создана дуэль #${room.id}, взнос ${stake}`,-stake);
        persist();
        return response(res,200,{room,user:sanitizedUser(user)});
      }
      const roomMatch=/^\/api\/rooms\/([0-9A-F]{8})\/(join|cancel)$/.exec(url.pathname);
      if(req.method==='POST' && roomMatch){
        const [ ,id,action]=roomMatch;
        const room=state.rooms[id];
        if(!room)bad('Комната не найдена',404);
        if(room.status!=='waiting')bad('Дуэль уже завершена');
        if(action==='cancel'){
          if(room.creatorId!==user.id)bad('Можно отменить только свою дуэль',403);
          user.balance+=room.stake;
          user.stats.spent-=room.stake;event(user,'spent',-room.stake);room.status='cancelled';
          addHistory(user,'pvp',`Дуэль #${id} отменена, взнос возвращён`,room.stake);
          persist();
          return response(res,200,{room,user:sanitizedUser(user)});
        }
        if(room.creatorId===user.id)bad('Нельзя играть против себя');
        if(user.balance<room.stake)bad('Недостаточно демо-звёзд');
        user.balance-=room.stake;user.stats.spent+=room.stake;event(user,'spent',room.stake);
        room.joinerId=user.id;
        room.joinerName=user.name;
        room.status='finished';
        let winnerId, award=0;
        if(room.caseId){
          const battleBox=activeCases().find(c=>c.id===room.caseId);
          if(!battleBox)bad('Кейс боя больше не существует');
          const a=[],b=[];
          for(let i=0;i<room.rounds;i++){
            a.push(pickByWeight(battleBox.drops,activeCatalog()));
            b.push(pickByWeight(battleBox.drops,activeCatalog()));
          }
          const va=a.reduce((n,x)=>n+x.value,0),vb=b.reduce((n,x)=>n+x.value,0);
          winnerId=va===vb?(crypto.randomInt(2)===0?room.creatorId:user.id):(va>vb?room.creatorId:user.id);
          room.rolls={creator:a,joiner:b};room.totals={creator:va,joiner:vb};
          const owner=state.users[winnerId];
          let prizeCount=0,starCredits=0;
          for(const item of [...a,...b]){
            if(item.kind==='stars')starCredits+=item.value;
            else {owner.inventory.unshift({...item,instanceId:crypto.randomUUID(),acquiredAt:new Date().toISOString()});prizeCount++;}
          }
          owner.balance+=starCredits;owner.stats.earned+=starCredits;
          if(starCredits)event(owner,'earned',starCredits);
          owner.stats.items+=prizeCount;
          room.awardItems=prizeCount;room.awardStars=starCredits;
        }else{
          winnerId=crypto.randomInt(2)===0?room.creatorId:user.id;
          award=room.stake*2;
          state.users[winnerId].balance+=award;
          state.users[winnerId].stats.earned+=award;
          event(state.users[winnerId],'earned',award);
        }
        const winner=state.users[winnerId];winner.stats.pvp++;event(winner,'pvp');
        room.winnerId=winnerId;room.winnerName=winner.name;
        addHistory(user,'pvp',`Дуэль #${id}: ${winnerId===user.id?'победа':'поражение'}`,room.caseId?0:(winnerId===user.id?room.stake:-room.stake));
        addHistory(state.users[room.creatorId],'pvp',`Дуэль #${id}: ${winnerId===room.creatorId?'победа':'поражение'}`,room.caseId?0:(winnerId===room.creatorId?room.stake*2:0));
        persist();
        return response(res,200,{room,user:sanitizedUser(user)});
      }
      // ROCKET: all players see the SAME round. Bets can be placed only during
      // the 10-second countdown. Nothing here transfers real Telegram Stars.
      if(req.method==='GET' && url.pathname==='/api/rocket/state'){
        const r=syncRocketRound();
        return response(res,200,{round:rocketView(r,user)});
      }
      if(req.method==='POST' && url.pathname==='/api/rocket/start'){
        const b=await bodyJson(req),stake=Number(b.stake);
        if(!Number.isSafeInteger(stake)||stake<1||stake>MAX_DEMO_STAKE)bad('Ставка должна быть целым числом от 1 до '+MAX_DEMO_STAKE+' демо-звёзд');
        const r=syncRocketRound();
        if(Date.now()>=r.startAt)bad('Раунд уже летит. Ждите следующего отсчёта.');
        if(r.bets[user.id])bad('В этом раунде ваша ставка уже принята');
        if(user.balance<stake)bad('Недостаточно демо-звёзд');
        r.bets[user.id]={stake,cashed:false,payout:0};
        user.balance-=stake;user.stats.spent+=stake;event(user,'spent',stake);
        addHistory(user,'rocket',`Rocket: ставка ${stake} ⭐ на раунд #${r.id.slice(0,6)}`,-stake);
        persist();
        return response(res,200,{round:rocketView(r,user),user:sanitizedUser(user)});
      }
      if(req.method==='POST' && url.pathname==='/api/rocket/cashout'){
        await bodyJson(req);
        const r=syncRocketRound(),bet=r.bets[user.id];
        if(!bet)bad('Вы не поставили на этот раунд');
        if(bet.cashed)bad('Вы уже забрали выигрыш');
        const now=Date.now();
        if(now<r.startAt)bad('Ракета ещё не взлетела');
        if(now>=r.startAt+r.crashAfter)bad('Ракета уже взорвалась');
        const multiplier=rocketMultiplier(now-r.startAt);
        const payout=Math.round(bet.stake*multiplier);
        bet.cashed=true;bet.payout=payout;bet.multiplier=multiplier;
        user.balance+=payout;user.stats.earned+=payout;user.stats.gameWins++;
        event(user,'earned',payout);event(user,'gameWins');
        addHistory(user,'rocket',`Rocket: забрано x${multiplier.toFixed(2)}`,payout);
        persist();
        return response(res,200,{round:rocketView(r,user),user:sanitizedUser(user)});
      }
      // MINES — bomb locations never appear in responses while the game is active.
      function minesView(r){
        if(!r)return null;
        return {id:r.id,stake:r.stake,count:r.count,status:r.status,revealed:r.revealed,
          multiplier:r.multiplier,payout:r.payout||0,
          mines:r.status==='active'?null:r.mines};
      }
      if(req.method==='GET'&&url.pathname==='/api/mines/state')return response(res,200,{round:minesView(state.mines[user.id]||null)});
      if(req.method==='POST'&&url.pathname==='/api/mines/start'){
        const b=await bodyJson(req);const stake=Number(b.stake),count=Number(b.count);
        if(!Number.isSafeInteger(stake)||stake<1||stake>MAX_DEMO_STAKE)bad('Ставка должна быть целым числом от 1 до '+MAX_DEMO_STAKE+' демо-звёзд');
        if(!Number.isInteger(count)||count<1||count>10)bad('Выберите 1–10 мин');
        if(state.mines[user.id]?.status==='active')bad('Сначала завершите текущую игру Mines');
        if(user.balance<stake)bad('Недостаточно демо-звёзд');
        const cells=Array.from({length:25},(_,i)=>i);
        for(let i=24;i>0;i--){const j=crypto.randomInt(i+1);[cells[i],cells[j]]=[cells[j],cells[i]];}
        const r={id:crypto.randomUUID(),status:'active',stake,count,mines:cells.slice(0,count),revealed:[],multiplier:1,payout:0};
        state.mines[user.id]=r;
        user.balance-=stake;user.stats.spent+=stake;event(user,'spent',stake);
        addHistory(user,'mines',`Mines: старт ${stake} ⭐, мин: ${count}`,-stake);
        persist();return response(res,200,{round:minesView(r),user:sanitizedUser(user)});
      }
      if(req.method==='POST'&&url.pathname==='/api/mines/reveal'){
        const b=await bodyJson(req),r=state.mines[user.id],cell=Number(b.cell);
        if(!r||r.status!=='active')bad('Нет активной игры Mines');
        if(!Number.isInteger(cell)||cell<0||cell>=25)bad('Неверная клетка');
        if(r.revealed.includes(cell))bad('Клетка уже открыта');
        if(r.mines.includes(cell)){
          r.status='lost';r.hit=cell;
          addHistory(user,'mines','Mines: попалась мина');
        }else{
          r.revealed.push(cell);
          let mult=.97;
          for(let i=0;i<r.revealed.length;i++)mult*=(25-i)/(25-r.count-i);
          r.multiplier=+mult.toFixed(3);
          if(r.revealed.length===25-r.count){
            r.status='won';r.payout=Math.round(r.stake*r.multiplier);
            user.balance+=r.payout;user.stats.earned+=r.payout;user.stats.gameWins++;
            event(user,'earned',r.payout);event(user,'gameWins');
            addHistory(user,'mines',`Mines: все безопасные клетки`,r.payout);
          }
        }
        persist();return response(res,200,{round:minesView(r),hit:r.hit===cell,user:sanitizedUser(user)});
      }
      if(req.method==='POST'&&url.pathname==='/api/mines/cashout'){
        const r=state.mines[user.id];
        if(!r||r.status!=='active'||r.revealed.length<1)bad('Откройте хотя бы одну безопасную клетку');
        r.status='cashed';r.payout=Math.round(r.stake*r.multiplier);
        user.balance+=r.payout;user.stats.earned+=r.payout;user.stats.gameWins++;
        event(user,'earned',r.payout);event(user,'gameWins');
        addHistory(user,'mines',`Mines: забрано x${r.multiplier.toFixed(2)}`,r.payout);
        persist();return response(res,200,{round:minesView(r),user:sanitizedUser(user)});
      }
      if(req.method==='GET' && url.pathname==='/api/cases'){
        return response(res,200,activeCases().map(c=>{
          const items=c.drops.map(([id,p])=>{const it=activeCatalog().find(x=>x.id===id);return {n:it.name,e:it.emoji,image:it.image,r:it.rarity[0].toUpperCase()+it.rarity.slice(1),value:it.value,p:p/100,kind:it.kind,priceType:it.priceType,floorTon:it.floorTon||null,floorSource:it.floorSource||null,observedAt:it.observedAt||null};});
          return {id:c.id,name:c.name,price:c.cost,color:c.color,theme:c.theme,symbol:c.symbol,items,ev:+items.reduce((s,i)=>s+i.value*i.p/100,0).toFixed(2)};
        }));
      }
      if(req.method==='POST' && url.pathname==='/api/demo-stars'){
        const wait=user.lastBonus+BONUS_COOLDOWN-Date.now();
        if(wait>0)return response(res,429,{error:'Следующие демо-звёзды будут доступны позже',wait});
        user.balance+=DAILY_BONUS;user.lastBonus=Date.now();
        addHistory(user,'bonus','Демо-звёзды',DAILY_BONUS);persist();
        return response(res,200,{user:sanitizedUser(user)});
      }
      return response(res,404,{error:'Такого API нет'});
    }
    response(res,404,{error:'Страница не найдена'});
  }catch(err){
    console.error('[request]',err.message);
    if(!res.headersSent)response(res,err.status||500,{error:err.status?err.message:'Внутренняя ошибка сервера'});
    else res.end();
  }
});
market.start();
server.listen(PORT,'0.0.0.0',()=>{
  console.log(`\n🧪 GIFT LAB STAGE 14.0 (curated cases · sandbox) запущен: http://localhost:${PORT}`);
  console.log(DEMO_MODE?'🔧 ДЕМО: открывайте приложение в браузере':'🔐 TELEGRAM: вход с проверкой initData (или задайте BOT_TOKEN)');
  console.log('⚠️ Игровой баланс только демо. XTR Supporter не связан с играми. JSON-хранилище не подходит для публичного production.\n');
  if(XTR_SUPPORT_ENABLED) startSupportPolling();
});

// Telegram Bot API polling for official XTR support-badge payment callbacks.
// Never run this at the same time as a webhook or a second bot worker.
async function telegramBot(method,body={},timeoutMs=15000){
  if(!TOKEN)throw Error('Отсутствует BOT_TOKEN');
  const endpoint=`https://api.telegram.org/bot${TOKEN}/${XTR_TEST_MODE?'test/':''}${method}`;
  const signal=AbortSignal.timeout(timeoutMs);
  const res=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal});
  const reply=await res.json().catch(()=>({}));
  if(!res.ok||!reply.ok)throw Error('Telegram '+method+': '+String(reply.description||res.status).slice(0,180));
  return reply.result;
}
async function processSupportUpdate(update){
  if(update.pre_checkout_query){
    const q=update.pre_checkout_query;
    const check=XTR.precheckout(state,q);
    await telegramBot('answerPreCheckoutQuery',{pre_checkout_query_id:q.id,...check},7000);
  }
  if(update.message?.successful_payment){
    const result=XTR.settle(state,update.message);
    if(result.accepted){
      const user=state.users[result.userId];
      addHistory(user,'support','Покупка Lab Supporter подтверждена · XTR (не игровой баланс)',0);
      persist();
      console.log('[xtr] Supporter badge delivered to Telegram user',result.userId);
    }
    if(result.reason==='mismatch')console.warn('[xtr] Payment mismatch: investigate via Telegram Stars transactions');
  }
}
let pollActive=false;
async function startSupportPolling(){
  if(pollActive)return;
  pollActive=true;
  const webhook=await telegramBot('getWebhookInfo').catch(e=>{console.error('[xtr]',e.message);return null});
  if(!webhook){pollActive=false;return}
  if(webhook.url){console.error('[xtr] Webhook is active; getUpdates polling will not work. Configure one update consumer instead.');pollActive=false;return}
  console.log('[xtr] Support badge invoice updates enabled in',XTR_TEST_MODE?'TEST':'LIVE','Telegram environment');
  while(pollActive){
    try{
      const updates=await telegramBot('getUpdates',{offset:state.supportUpdateOffset,timeout:18,limit:30,allowed_updates:['pre_checkout_query','message']},25000);
      for(const update of updates){
        await processSupportUpdate(update);
        state.supportUpdateOffset=update.update_id+1;
        persist();
      }
    }catch(e){
      console.error('[xtr]',e.message);
      await new Promise(r=>setTimeout(r,4000));
    }
  }
}
